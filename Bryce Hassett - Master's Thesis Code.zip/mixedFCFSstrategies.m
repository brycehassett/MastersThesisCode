% This function generates the heatmaps for the social welfare and 
% throughput of the system over various off-equilibrium strategies 
% in Section 3.3.2 (Figures 3.13, 3.14, and A.1 to A.6).
% By Bryce Hassett

clc;
clear;
close all;
format short

rng(1);
trials = 100; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.5;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
simulationTime = 1000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 6; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
gamma = 0.8; % Proportion of informed customers
probs = 0:0.05:1; % Possible joining probabilities for uninformed
thresh = 1:20; % Possible joining thresholds for informed

meanIdle = [];
meanWelfare = [];

count = 0;
for i = 1:length(probs)
    q = probs(i);
    for j = 1:length(thresh)
        
        N = thresh(j);
        [mixedAvg, mixedCILow, mixedCIHigh] = mixedQueue(lambda, mu, R, C, gamma, q, N, simulationTime, trials, plots);

        meanIdle(i,j) = mixedAvg(5);
        meanWelfare(i,j) = mixedAvg(8);
        count = count + 1;


        disp(['Finished ', num2str(count), ' of ', num2str(length(probs)*length(thresh))])
    end
end

% Average welfare
figure;
h1 = heatmap(thresh, probs, meanWelfare);

sh = struct(h1);
sh.Axes.XLabel.FontSize = 16;
sh.Axes.YLabel.FontSize = 16;
sh.Axes.Title.FontSize = 16;

title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f, gamma = %.2f)', lambda, R, gamma);
h1.Title = title_str;
h1.XLabel = 'Informed customer threshold, n';
h1.YLabel = 'Uninformed customer joining probability, q';
grid on;

% Average proportion of idle time
figure;
h2 = heatmap(thresh, probs, meanIdle);

sh = struct(h2);
sh.Axes.XLabel.FontSize = 16;
sh.Axes.YLabel.FontSize = 16;
sh.Axes.Title.FontSize = 16;

title_str = sprintf('Average Idle Time (lambda = %.1f, R = %.1f, gamma = %.2f)', lambda, R, gamma);
h2.Title = title_str;
h2.XLabel = 'Informed customer threshold, n';
h2.YLabel = 'Uninformed customer joining probability, q';
grid on;