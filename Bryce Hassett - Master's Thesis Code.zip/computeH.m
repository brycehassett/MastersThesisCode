% This functions computes the values of H(m,n)i,j to use in the 
% equilibrium calculation function obsPriorEquil.m.
% By Bryce Hassett

function H = computeH(m, lambda, mu, B1)

% H(i+1,j+1) = H_{i,j}^{[m,n]}
% Invalid entries remain NaN.

H = NaN(m+1,m+1);

if m == 1
    % H_{0,1}=0
    H(1,2) = 0;

    % Equation (8)
    H(2,1) = (1 + lambda*B1)/mu;
    return
end

H(2,m) = (1 + lambda*B1)/mu; % boundary condition H_{1,m-1}


% Equation (9) (Compute H_{1,a},  a=m-2,...,0)
for a = m-2:-1:0
    H(2,a+1) = 1/(mu+lambda) + lambda/(mu+lambda)*H(2,a+2);
end


% Equation (8) (Compute diagonal entries H_{i,m-i})
for i = 2:m-1
    H(i+1,m-i+1) = (1 + lambda*B1)/mu + H(i,m-i+1);
end


% Equation (10) (Fill interior)
for i = 2:m-1
    % diagonal
    H(i+1,m-i+1) = (1 + lambda*B1)/mu + H(i,m-i+1);
    % move left across the row
    for k = m-i-1:-1:0
        H(i+1,k+1) = 1/(mu+lambda) + lambda/(mu+lambda)*H(i+1,k+2) + mu/(mu+lambda)*H(i,k+1);
    end
end

H(m+1,1) = (1 + lambda*B1)/mu + H(m,1);
end