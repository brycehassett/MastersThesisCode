% Computing the expected utilities for ordinary and priority uninformed customers in the MIPQ
% By Bryce Hassett

clc
clear
close all

tic;
rng(1);
trials = 10000;

% M/M/1 Queue Simulation
lambda = 1;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
maxTime = 100; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 10; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
P = 4; % Priority fee
gamma = 0.5;
q = 0.7;
p = 0.25;

rho = lambda/mu; % System load
maxM = 12;
maxN = 12;

A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);

vR = R*mu/C; % Service reward relative to average waiting cost for a service cycle
vP = P*mu/C; % Priority premium relative to average waiting cost for a service cycle
n = floor(vR - vP) - 1; % threshold between balking and joining with priority

%%
clc
% Compute stationary distribution (TO DO)
pi = mipqUninfStatDist(lambda, mu, gamma, q, p, A, maxM, maxN);
idleProb = pi(1);
pi = pi(2:end);

runs = 1000;
% Compute expected sojourn times from each state
[Wo, Wp] = mipqUninfWaitTimes(lambda, mu, gamma, R, P, C, q, p, A, maxTime, runs); % matrices

% Convert to column vector to match stationary distribution pi
Wo = Wo(:);
Wp = Wp(:);

% Compute overall expected sojourn times, from stationary distribution
EW_o = sum(pi .* Wo) + idleProb/mu;
EW_p = sum(pi .* Wp) + idleProb/mu;

% Calculate the expected utilities
ordUtil = R - C*EW_o;
priorUtil = R - P - C*EW_p;