% This function simulates the fully unobservable priority queue, 
% from Section 4.1, for a specified parameter set, and outputs a sample 
% path and the resulting performance measures (for example, Figures 4.3 and 4.4).
% By Bryce Hassett

function [means, ciLower, ciUpper] = mm1unobsPrior(lambda, mu, R, C, P, q, p, simulationTime, trials, plot)

unobsPriorResults = [];

for j = 1:trials

    % Initialization
    currentTime = 0;
    serverFlag = 0; % 0 if server is idle, 1 if busy
    priorCustomersInQueue = 0; % Number of priority customers in the queue
    normCustomersInQueue = 0; % Number of ordinary customers in the queue
    timeEvents = 0; % Times when either an arrival or departure occurs
    stateEvents = 0; % Number of customers in system when an event occurs
    idleTime = 0; % Keep track of idle time
    arrivals = 0; % Number of customers who arrive at the queue
    arrivalTimes = [];
    normTimes = 0; % All times when ordinary customers either arrive or leave
    priorTimes = 0; % All times when priority customers either arrive or leave
    normState = 0; % Number of ordinary customers when an event occurs
    priorState = 0; % Number of priority customers when an event occurs
    departureTimes = [];
    customerLabels = []; % Keep track of which customers are ordinary (1) and which are priority (0)
    priorFlag = 1; % Current customer event (either arrival or departure), 1 if ordinary, 0 if priority

    % Simulation Loop
    while currentTime < simulationTime
        % Generate next arrival and service times (Exponential Distribution)
        arrivalInterval = exprnd(1/(q*lambda)); % The effective arrival rate
        serviceDuration = exprnd(1/mu);
        
        if serverFlag == 0
            nextEvent = arrivalInterval;
        else
            if arrivalInterval < serviceDuration
                nextEvent = arrivalInterval;
            else
                nextEvent = serviceDuration;
            end
        end
        if currentTime + nextEvent > simulationTime % Exit the loop if the next arrival/service event exceeds simulation time
            break;
        end

        % If system is empty, next event must be an arrival
        if serverFlag == 0
            serverFlag = 1;
            idleTime = idleTime + arrivalInterval;
            currentTime = currentTime + arrivalInterval;
            arrivals = arrivals + 1;
            arrivalTimes = [arrivalTimes, currentTime];
            if rand() > p % the first arrival is an ordinary customer
                priorFlag = 1;
                customerLabels = [customerLabels, 1]; % Index with an ordinary customer
            else
                priorFlag = 0;
                customerLabels = [customerLabels, 0]; % Index with a priority customer
            end
        else
            % Compare next arrival and next service completion (this works
            % because of the memoryless property of exponentials)
            if arrivalInterval < serviceDuration
                % Arrival happens first
                currentTime = currentTime + arrivalInterval;
                %customersInSystem = customersInSystem + 1;
                arrivals = arrivals + 1;
                if rand() > p % the next arrival is an ordinary customer
                    priorFlag = 1;
                    normCustomersInQueue = normCustomersInQueue + 1;
                    arrivalTimes = [arrivalTimes, currentTime]; % send to the back of the queue
                    customerLabels = [customerLabels, 1]; % Index with an ordinary customer
                else % the next arrival is a priority customer, so insert it in front of all ordinary customers in the queue
                    priorFlag = 0;
                    priorCustomersInQueue = priorCustomersInQueue + 1;
                    % For non-preemption priority queue
                    if arrivals == length(arrivalTimes) + normCustomersInQueue + 1 % new priority customer is at the end of the line, which is empty (rare case, when there are no ordinary customers)
                        arrivalTimes = [arrivalTimes(1:arrivals-normCustomersInQueue-1), currentTime];
                        customerLabels = [customerLabels(1:arrivals-normCustomersInQueue-1), 0];
                    else
                        arrivalTimes = [arrivalTimes(1:arrivals-normCustomersInQueue-1), currentTime, arrivalTimes(arrivals-normCustomersInQueue:end)];
                        customerLabels = [customerLabels(1:arrivals-normCustomersInQueue-1), 0, customerLabels(arrivals-normCustomersInQueue:end)]; % Index with a priority customer
                    end
                end

            else
                % Service completion happens first
                currentTime = currentTime + serviceDuration;
                if normCustomersInQueue + priorCustomersInQueue == 0 % server is now idle
                    serverFlag = 0;
                end
                if customerLabels(length(departureTimes)+1) == 1 % ordinary customer leaves
                    priorFlag = 1;
                else
                    priorFlag = 0;
                end
                if serverFlag == 1
                    
                    if customerLabels(length(departureTimes)+2) == 1 % next customer to go into service is ordinary
                        normCustomersInQueue = max(0, normCustomersInQueue - 1);
                    else
                        priorCustomersInQueue = max(0, priorCustomersInQueue - 1);
                    end
                end
                departureTimes = [departureTimes, currentTime];
                
            end
        end

        % Record events for plotting
        timeEvents = [timeEvents, currentTime];
        stateEvents = [stateEvents, serverFlag + normCustomersInQueue + priorCustomersInQueue];

        if priorFlag == 1 % ordinary customer either arrives or leaves
            normTimes = [normTimes, currentTime];
            normState = [normState, normCustomersInQueue];
        else
            priorTimes = [priorTimes, currentTime];
            priorState = [priorState, priorCustomersInQueue];
        end
    end

    % for debugging
    timeEvents;
    stateEvents;
    normTimes;
    priorTimes;
    normState;
    priorState;
    arrivalTimes;
    departureTimes;
    customerLabels;

    % Calculating the average queue length (area under plot)
    totalTime = 0;
    i = 1;
    while i < length(stateEvents)
        totalTime = totalTime + (stateEvents(i) * (timeEvents(i+1)-timeEvents(i)));
        i = i+1;
    end
    averageLength = totalTime / simulationTime;

    % Calculating the average queue length (area under plot) for ordinary and priority queues
    totalNormTime = 0;
    i = 1;
    while i < length(normState)
        totalNormTime = totalNormTime + (normState(i) * (normTimes(i+1)-normTimes(i)));
        i = i+1;
    end
    averageNormLength = totalNormTime / simulationTime;

    totalPriorTime = 0;
    i = 1;
    while i < length(priorState)
        totalPriorTime = totalPriorTime + (priorState(i) * (priorTimes(i+1)-priorTimes(i)));
        i = i+1;
    end
    averagePriorLength = totalPriorTime / simulationTime;

    % Calculating the average (sojourn) time for a customer in the system
    arrivalTimesFixed = arrivalTimes(1:length(departureTimes)); % Match the arrivals with departures, to consider only customers who finish service
    customerWait = departureTimes - arrivalTimesFixed; % Each individual customer's time in system
    averageCustomerTime = sum(customerWait) / length(arrivalTimesFixed);

    % Calculating the average sojourn time for normal and priority customers separately
    customerLabelsFixed = customerLabels(1:length(departureTimes));
    normWait = (departureTimes - arrivalTimesFixed) .* customerLabelsFixed;
    priorWait = (departureTimes - arrivalTimesFixed) .* (1-customerLabelsFixed);
    averagePriorTime = sum(priorWait) / sum(1-customerLabelsFixed);
    averageNormTime = sum(normWait) / sum(customerLabelsFixed);

    % Calculating the proportion of time spent idle
    propIdle = idleTime / simulationTime;

    % Calculating the social welfare (sum of customer utilities)
    welfare = (R*length(departureTimes) - P*sum(1-customerLabelsFixed) - C*sum(customerWait))/simulationTime;

    % Plotting the sample path
    if plot == 1 && j == 1
        figure;
        hold on;
        stairs(timeEvents, stateEvents, 'LineWidth', 1.5); % total number of customers
        stairs(normTimes, normState, 'LineWidth', 1.5); % number of ordinary customers
        stairs(priorTimes, priorState, 'LineWidth', 1.5); % number of priority customers
        title_str = sprintf('Unobservable Priority Queue (lambda = %.1f, mu = %.1f, R = %.1f, C = %.1f, P = %.1f)', lambda, mu, R, C, P);
        title(title_str, "FontSize", 20);
        xlabel('Time (minutes)', "FontSize", 20);
        ylabel('Number of Customers in System', "FontSize", 20);
        legend('Total', 'Ordinary', 'Priority');
        grid on;
    end

    trialResults = [averageLength, averageNormLength, averagePriorLength, averageCustomerTime, averageNormTime, averagePriorTime, propIdle, q, p, welfare];
    unobsPriorResults(end+1, :) = trialResults;
end
unobsPriorResults; % all results
[~, ~, ci] = ttest(unobsPriorResults);
means = mean(unobsPriorResults, 1);
ciLower = ci(1:2:end);
ciUpper = ci(2:2:end);
end