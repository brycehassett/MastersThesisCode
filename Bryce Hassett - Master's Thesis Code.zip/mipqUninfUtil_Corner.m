% This function computes the expected utilities for an arriving uninformed 
% ordinary and priority customer in the MIPQ when 
% q ∈ {0, 1} and p ∈ {0, 1} (i.e. corner values).
% By Bryce Hassett

function F = mipqUninfUtil_Corner(lambda, mu, gamma, R, C, P, q, p, trials, runs, maxTime, maxM, maxN)

%disp("Computing A...")
A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);

% Compute stationary distribution (TO DO)
%disp("Computing pi...")
pi = mipqUninfStatDist(lambda, mu, gamma, q, p, A, maxM, maxN);
idleProb = pi(1);
pi = pi(2:end);
% transpose
pi = reshape(pi, maxM+1, maxN+1);
pi = transpose(pi);
pi = pi(:);
pi_Matrix = reshape(pi, maxM+1, maxN+1);

% Compute expected sojourn times from each state
%disp("Computing expected sojourn times...")
[Wo, Wp] = mipqUninfWaitTimes(lambda, mu, gamma, R, P, C, q, p, A, maxTime, runs, pi_Matrix); % matrices

% Convert to column vector to match stationary distribution pi
Wo = Wo(:);
Wp = Wp(:);

% Compute overall expected sojourn times, from stationary distribution
EW_o = sum(pi .* Wo) + idleProb/mu;
EW_p = sum(pi .* Wp) + idleProb/mu;

% Calculate the expected utilities
F(1) = R - C*EW_o;
F(2) = R - P - C*EW_p;
end