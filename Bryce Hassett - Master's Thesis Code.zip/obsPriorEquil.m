% This function computes the equilibrium strategy (m, n) for the 
% fully observable priority queue, from Section 4.2.1. It also plots the 
% expected waiting time and individual utility for various values of m, 
% to demonstrate the existence of multiple equilibria (Figure 4.11).
% By Bryce Hassett

function [m,n] = obsPriorEquil(lambda, mu, R, C, P)

plots = 0;

% Calculate the equilibrium values for the thresholds m and n (from Wang, Cui, Wang (2019), Thm 4)
rho = lambda/mu; % System load
vR = R*mu/C; % Service reward relative to average waiting cost for a service cycle
vP = P*mu/C; % Priority premium relative to average waiting cost for a service cycle

n = floor(vR - vP) - 1;
if rho == 1 % to avoid errors
    B1 = n; % converges to n
else
    B1 = 1/(mu-lambda) + (1/mu - 1/(mu-lambda))*(rho^(n-1)-rho^n)/(1-rho);
end

lowerM = 1;
upperM = 60;
range = lowerM:upperM;

if vP >= vR - 2 % priority is too expensive
    m = floor(vR) - 1;
    n = 0;
elseif vP < lambda*B1 % priority is too cheap
    m = 0;
    n = floor(vR - vP) - 1;
else % we need to compute an m that satisfies the inequality (11) in Wang, Cui, and Wang. 
    
    Hall = cell(upperM - lowerM + 1, 1);
    Hm0 = [];

    for m = 1:upperM - lowerM + 1
        Hall{m} = computeH(m, lambda, mu, B1);
        Hm0(m) = Hall{m}(m+1,1);
    end
    possibles = [];
    for i = 1:upperM - lowerM + 1
        if (vP-1-lambda*B1 <= mu*Hm0(i)-1) && (mu*Hm0(i)-1 <= vP)
            possibles = [possibles, i];
        end
    end
    
    utilities = [];
    maxUtility = 0;

    for i = 1:length(possibles)
        sum1 = 0;
        sum2 = 0;
        for j = 1:possibles(i)
            sum1 = sum1 + rho^j*C*Hall{possibles(i)}(j+1,1);
        end
        for k = 1:n
            sum2 = sum2 + rho^k*(P+k*C/mu);
        end
        if rho == 1 % to avoid errors
            utilities = [utilities, -0.2*sum1-0.2+3.2]; % when P=2, n=2
        else
            utilities = [utilities, (1-rho^(possibles(i)+n+1))/(1-rho^(possibles(i)+n+2))*(R-C/mu)-(1-rho)/(1-rho^(possibles(i)+n+2))*(sum1+rho^possibles(i)*sum2)];
        end
        if utilities(i) > maxUtility % take Pareto-dominant equilibrium
            maxUtility = utilities(i);
            maxUtilIndex = i;
        end
    end

    if plots == 1
        allUtilities = [];
        for i = 1:upperM-lowerM+1
            sum1 = 0;
            sum2 = 0;
            for j = 1:range(i)
                sum1 = sum1 + rho^j*C*Hall{range(i)}(j+1,1);
            end
            for k = 1:n
                sum2 = sum2 + rho^k*(P+k*C/mu);
            end
            allUtilities = [allUtilities, (1-rho^(range(i)+n+1))/(1-rho^(range(i)+n+2))*(R-C/mu)-(1-rho)/(1-rho^(range(i)+n+2))*(sum1+rho^range(i)*sum2)];
        end
    end

    m = possibles(maxUtilIndex);
    n = floor(vR - vP) - 1;

    if plots == 1
        thresh = lowerM:upperM;
        lower = [];
        upper = [];
        horiz = (1/mu + P/C)*ones(1, upperM - lowerM + 1);

        for i = 1:upperM - lowerM + 1
            lower(i) = Hall{i}(i+1,1);
            upper(i) = Hall{i}(i+1,1) + (1+lambda*B1)/mu;
        end

        figure;
        hold on;
        plot(thresh, lower, '.', LineStyle=':', MarkerSize=25)
        plot(thresh, upper, '.', LineStyle=':', MarkerSize=25)
        plot(thresh, horiz, '.', LineStyle='-', MarkerSize=2)
        xlabel('m', 'FontSize', 20);
        ylabel('Expected waiting time', "FontSize", 20);
        title_str = sprintf('Equilibria when P = %.0f', P);
        title(title_str, "FontSize", 20);

        figure;
        plot(thresh, allUtilities, '.', LineStyle=':', MarkerSize=25)
        xlabel('m', 'FontSize', 20);
        ylabel('Expected individual utility', "FontSize", 20);
        title_str = sprintf('Individual utility when P = %.0f', P);
        title(title_str, "FontSize", 20);
    end
end