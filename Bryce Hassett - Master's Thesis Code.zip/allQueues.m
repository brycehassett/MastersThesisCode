% The main executable script used to run simulations for each queueing model 
% and display the output variables for each. This was utilised for the core 
% models in Chapters 3 and 4. 
% By Bryce Hassett

% Uncomment the queue you wish to test

clc
clear
close all

rng(1);
plots = 1; % 0 if plots NOT produced, 1 if plots produced (one sample path per model)
trials = 100;

% M/M/1 Queue Simulation
lambda = 1.5;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
simulationTime = 10000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 10; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
P = 5; % Priority fee

% % M/M/1 Queue
% if lambda < mu % need this condition for the M/M/1 queue to make sense
%     disp("M/M/1 Queue")
%     disp("averageLength, averageCustomerTime, propIdle")
%     % Outputs averageLength, averageCustomerTime, propIdle
%     mm1Results = mm1(lambda, mu, simulationTime) % inputs are arrival rate, service rate, simulation time
% end


% % M/M/1 Unobservable Queue (with balking)
% disp("M/M/1 Unobservable Queue")
% q = unobsEquil(lambda, mu, R, C);
% q = 0 % testing equilibrium
% [unobsAvg, unobsCILow, unobsCIHigh] = mm1unobservable(lambda, mu, R, C, q, simulationTime, trials, plots); % inputs are arrival rate, service rate, reward, cost per unit time, simulation time
% 
% Mean = transpose(unobsAvg);
% Lower = transpose(unobsCILow);
% Upper = transpose(unobsCIHigh);
% Variable = ["averageLength"; "averageCustomerTime"; "propIdle"; "joinProb"; "welfare"];
% unobsCITable = table(Variable, Mean, Lower, Upper)
% disp("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-")


% % M/M/1 Observable Queue (with balking)
% disp("M/M/1 Observable Queue")
% N = floor(R*mu/C); % Threshold equilibrium for joining decision (join if there are less than or equal to N customers in the system)
% [obsAvg, obsCILow, obsCIHigh] = mm1observable(lambda, mu, R, C, N, simulationTime, trials, plots); % inputs are arrival rate, service rate, reward, cost per unit time, simulation time
% 
% Mean = transpose(obsAvg);
% Lower = transpose(obsCILow);
% Upper = transpose(obsCIHigh);
% Variable = ["averageLength"; "averageCustomerTime"; "propIdle"; "propJoin"; "welfare"];
% obsCITable = table(Variable, Mean, Lower, Upper)
% disp("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-")


% % Mixed Information Queue
% gamma = 0.9; % Proportion of informed customers
% %q = 0.5556; % Joining probability for uninformed customers
% %N = floor(R*mu/C); % Threshold for joining decision of informed customers (join if there are N or less customers in the system)
% 
% [N, q] = mixedEquil(lambda, mu, R, C, gamma);
% disp("Mixed Information Queue")
% [mixedAvg, mixedCILow, mixedCIHigh] = mixedQueue(lambda, mu, R, C, gamma, q, N, simulationTime, trials, plots);
% 
% Mean = transpose(mixedAvg);
% Lower = transpose(mixedCILow);
% Upper = transpose(mixedCIHigh);
% Variable = ["averageLength"; "averageCustomerTime"; "averageUninformedTime"; "averageInformedTime"; "propIdle"; "joinProb"; "propJoinInformed"; "welfare"];
% mixedCITable = table(Variable, Mean, Lower, Upper)
% disp("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-")


% % M/M/1 Unobservable (Non-preemptive) Priority Queue (with balking)
% disp("M/M/1 Unobservable Priority Queue")
% [q,p] = unobsPriorEquil(lambda, mu, R, C, P);
% [unobsPriorAvg, unobsPriorCILow, unobsPriorCIHigh] = mm1unobsPrior(lambda, mu, R, C, P, q, p, simulationTime, trials, plots); % inputs are arrival rate, service rate, reward, cost per unit time, priority fee, simulation time
% 
% Mean = transpose(unobsPriorAvg);
% Lower = transpose(unobsPriorCILow);
% Upper = transpose(unobsPriorCIHigh);
% Variable = ["averageLength"; "averageNormLength"; "averagePriorLength"; "averageCustomerTime"; "averageNormTime"; "averagePriorTime"; "propIdle"; "joinProb"; "priorProb"; "welfare"];
% unobsPriorCITable = table(Variable, Mean, Lower, Upper)
% disp("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-")


% % M/M/1 Observable (Non-preemptive) Priority Queue (with balking)
% disp("M/M/1 Observable Priority Queue")
% [m, n] = obsPriorEquil(lambda, mu, R, C, P)
% [obsPriorAvg, obsPriorCILow, obsPriorCIHigh] = mm1obsPrior(lambda, mu, R, C, P, m, n, simulationTime, trials, plots); % inputs are arrival rate, service rate, reward, cost per unit time, priority fee, simulation time
% 
% Mean = transpose(obsPriorAvg);
% Lower = transpose(obsPriorCILow);
% Upper = transpose(obsPriorCIHigh);
% Variable = ["averageLength"; "averageNormLength"; "averagePriorLength"; "averageCustomerTime"; "averageNormTime"; "averagePriorTime"; "propIdle"; "propJoin"; "propPrior"; "welfare"];
% obsPriorCITable = table(Variable, Mean, Lower, Upper)
% disp("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-")



% % Mixed Information Priority Queue (MIPQ)
% gamma = 0.8; % Proportion of informed customers
% 
% % for testing
% %q = 1;
% %p = 1;
% 
% % Equilibrium calculation for informed customers
% runs = 100; % number of repetitions when computing expected waiting time for uninformed customer
% maxTime = 100; % max time for a tagged customer, when calculating equilibrium
% maxM = floor(15*lambda/mu);
% maxN = floor(15*lambda/mu);
% 
% % testing
% %A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, runs, maxTime, maxM, maxN);
% %[mixedPriorAvg, mixedPriorCILow, mixedPriorCIHigh] = mixedPriorQueue(lambda, mu, R, C, P, gamma, q, p, A, maxM, maxN, simulationTime, trials, plots);
% 
% % [q,p,A] = mipqFullEquil(lambda, mu, gamma, R, C, P, trials, runs, maxTime, maxM, maxN);
% % 
% % % Find which equilibrium is the Pareto-dominant one
% % utilEquil = []; % stores the utilities, for each equilibrium
% % idleEquil = []; % stores idle proportion, for each equilibrium
% % effRateEquil = []; % stores the effective arrival rate, for each equilibrium
% % for i = 1:length(q)
% %     disp("Mixed Information Priority Queue")
% %     InfA = A(:, (maxM+1)*(i-1)+1:(maxM+1)*i);
% %     disp("q = " + q(i))
% %     disp("p = " + p(i))
% %     [mixedPriorAvg, mixedPriorCILow, mixedPriorCIHigh] = mixedPriorQueue(lambda, mu, R, C, P, gamma, q(i), p(i), InfA, maxM, maxN, simulationTime, trials, plots);
% % 
% %     Mean = transpose(mixedPriorAvg);
% %     Lower = transpose(mixedPriorCILow);
% %     Upper = transpose(mixedPriorCIHigh);
% %     Variable = ["averageLength"; "averageNormLength"; "averagePriorLength"; "propIdle"; "averageCustomerTime"; "averageNormTime"; "averagePriorTime"; "averageUninfTime"; "averageInfTime"; "avgUninfNormTime"; "avgInfNormTime"; "avgUninfPriorTime"; "avgInfPriorTime"; "propJoin"; "propUninfJoin"; "propInfJoin"; "propPrior"; "propUninfPrior"; "propInfPrior"; "welfare"];
% %     obsPriorCITable = table(Variable, Mean, Lower, Upper)
% %     idleEquil(i) = mixedPriorAvg(4);
% %     effRateEquil(i) = mixedPriorAvg(14)*lambda;
% %     utilEquil(i) = mixedPriorAvg(end);
% %     disp("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-")
% % end
% % [maxUtil, idx] = max(utilEquil)
% % qEquil = q(idx)
% % pEquil = p(idx)
% % AEquil = A(:, (maxM+1)*(idx-1)+1:(maxM+1)*idx)
% % idleProb = idleEquil(idx);
% % lambdaEffective = effRateEquil(idx);