% This function runs simulations of the fully observable FCFS queue over 
% various joining thresholds, n, and generates the plots for social welfare 
% and throughput in Section 3.2.2 (Figure 3.8).
% By Bryce Hassett

clc;
clear;
close all;
format short

rng(1);
trials = 100; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.5;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
simulationTime = 10000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 6; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
thresh = 1:20; % Possible thresholds (customer joins if queue length, plus service, is less than this)

meanIdle = [];
lowerIdle = [];
upperIdle = [];
meanWelfare = [];
lowerWelfare = [];
upperWelfare = [];

for i = 1:length(thresh)
    n = thresh(i);
    [obsAvg, obsCILow, obsCIHigh] = mm1observable(lambda, mu, R, C, n, simulationTime, trials, plots);

    meanIdle = [meanIdle, obsAvg(3)];
    lowerIdle = [lowerIdle, obsCILow(3)];
    upperIdle = [upperIdle, obsCIHigh(3)];

    meanWelfare = [meanWelfare, obsAvg(5)];
    lowerWelfare = [lowerWelfare, obsCILow(5)];
    upperWelfare = [upperWelfare, obsCIHigh(5)];

    disp(['Finished ', num2str(i), ' of ', num2str(length(thresh))])
end

% Average idle time
idleNeg = meanIdle - lowerIdle;
idlePos = upperIdle - meanIdle;
figure;
hold on;
errorbar(thresh, meanIdle, idleNeg, idlePos, '-o', 'LineWidth', 2)
title_str = sprintf('Average Proportion of Idle Time (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('n', "FontSize", 20);
ylabel('Average idle time', "FontSize", 20);
grid on;

% Average welfare
welfareNeg = meanWelfare - lowerWelfare;
welfarePos = upperWelfare - meanWelfare;
figure;
hold on;
errorbar(thresh, meanWelfare, welfareNeg, welfarePos, '-o', 'LineWidth', 2)
title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('n', "FontSize", 20);
ylabel('Social Welfare', "FontSize", 20);
grid on;