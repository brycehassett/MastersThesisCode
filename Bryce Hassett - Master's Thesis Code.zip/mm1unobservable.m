% This function simulates the fully unobservable FCFS queue, from 
% Section 3.1, for a specified parameter set, and outputs a sample path 
% and the resulting performance measures (for example, Figures 3.2 and 3.3)
% By Bryce Hassett

function [means, ciLower, ciUpper] = mm1unobservable(lambda, mu, R, C, q, simulationTime, trials, plot)

unobsResults = [];

for j = 1:trials
    % Initialization
    currentTime = 0;
    customersInSystem = 0;
    timeEvents = 0; % Times when either an arrival or departure occurs
    stateEvents = 0; % Number of customers in system when an event occurs
    idleTime = 0; % Keep track of idle time
    arrivals = 0; % Number of customers who arrive at the queue
    balks = 0; % Number of customers who do not join the queue
    arrivalTimes = [];
    departureTimes = [];

    % Simulation Loop
    while currentTime < simulationTime
        % Generate next arrival and service times (Exponential Distribution)
        arrivalInterval = exprnd(1/(q*lambda)); % The effective arrival rate is q*lambda
        serviceDuration = exprnd(1/mu);
        if customersInSystem == 0
            nextEvent = arrivalInterval;
        else
            if arrivalInterval < serviceDuration
                nextEvent = arrivalInterval;
            else
                nextEvent = serviceDuration;
            end
        end
        if currentTime + nextEvent > simulationTime % Exit the loop if the next arrival/service event exceeds simulation time
            break;
        end
        % If system is empty, next event must be an arrival
        if customersInSystem == 0
            idleTime = idleTime + arrivalInterval;
            currentTime = currentTime + arrivalInterval;
            customersInSystem = 1;
            arrivals = arrivals + 1;
            arrivalTimes = [arrivalTimes, currentTime];
        else
            % Compare next arrival and next service completion (this works
            % because of the memoryless property of exponentials)
            if arrivalInterval < serviceDuration
                % Arrival happens first
                currentTime = currentTime + arrivalInterval;
                customersInSystem = customersInSystem + 1;
                arrivals = arrivals + 1;
                arrivalTimes = [arrivalTimes, currentTime];
            else
                % Service completion happens first
                currentTime = currentTime + serviceDuration;
                customersInSystem = customersInSystem - 1;
                departureTimes = [departureTimes, currentTime];
            end
        end

        % Record events for plotting
        timeEvents = [timeEvents, currentTime];
        stateEvents = [stateEvents, customersInSystem];
    end

    % for debugging
    timeEvents;
    stateEvents;
    arrivalTimes;
    departureTimes;

    % Calculating the average queue length (area under plot)
    totalTime = 0;
    i = 1;
    while i < length(stateEvents)
        totalTime = totalTime + (stateEvents(i) * (timeEvents(i+1)-timeEvents(i)));
        i = i+1;
    end
    averageLength = totalTime / simulationTime;

    % Calculating the average (sojourn) time for a customer in the system
    arrivalTimesFixed = arrivalTimes(1:length(departureTimes)); % Match the arrivals with departures, to consider only customers who finish service
    customerWait = departureTimes - arrivalTimesFixed; % Each individual customer's time in system
    averageCustomerTime = sum(customerWait) / length(arrivalTimesFixed);

    % Calculating the proportion of time spent idle
    if q == 0
        propIdle = 1;
    else
        propIdle = idleTime / simulationTime;
    end

    % Calculating the proprtion of customers who actually join the system
    propJoin = q;

    % Calculating the social welfare (sum of customer utilities)
    welfare = (R*length(departureTimes) - C*sum(customerWait))/simulationTime;

    % Plotting the first sample path
    if plot == 1 && j == 1
        figure;
        stairs(timeEvents, stateEvents, 'LineWidth', 1.5);
        title_str = sprintf('Unobservable Queue Simulation (lambda = %.1f, mu = %.1f, q = %.3f)', lambda, mu, q);
        title(title_str, "FontSize", 20);
        xlabel('Time (minutes)', "FontSize", 20);
        ylabel('Number of Customers in System', "FontSize", 20);
        grid on;
    end

    trialResults = [averageLength, averageCustomerTime, propIdle, propJoin, welfare];
    unobsResults(end+1, :) = trialResults;
end
unobsResults; % all results
[~, ~, ci] = ttest(unobsResults);
means = mean(unobsResults, 1);
ciLower = ci(1:2:end);
ciUpper = ci(2:2:end);
end