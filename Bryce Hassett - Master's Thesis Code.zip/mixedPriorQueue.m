% This function simulates the mixed information priority queue, 
% from Chapter 5, for a specified parameter set, and outputs a sample path 
% and the resulting performance measures (for example, Figure 5.11).
% By Bryce Hassett

function [means, ciLower, ciUpper] = mixedPriorQueue(lambda, mu, R, C, P, gamma, q, p, A, maxM, maxN, simulationTime, trials, plot)
mixedPriorResults = [];

for j = 1:trials
    % Initialization
    currentTime = 0;
    serverFlag = 0; % 0 if server is idle, 1 if server is busy
    N = 0; % Number of priority customers in the queue (excluding one in service)
    totalUninfPriors = 0; % Total number of uninformed priority customers who were served
    totalInfPriors = 0; % Total number of informed priority customers who were served
    M = 0; % Number of ordinary customers in the queue (excluding one in service)
    totalUninfNorms = 0; % Total number of uninformed ordinary customers who were served
    totalInfNorms = 0; % Total number of informed ordinary customers who were served
    timeEvents = 0; % Times when either an arrival or departure occurs
    stateEvents = 0; % Number of customers in system when an event occurs
    idleTime = 0; % Keep track of idle time
    arrivals = 0; % Number of customers who arrive at the queue
    arrivalTimes = [];
    normTimes = 0; % All times when ordinary customers either arrive or leave
    priorTimes = 0; % All times when priority customers either arrive or leave
    normState = 0; % Number of ordinary customers when an event occurs
    priorState = 0; % Number of priority customers when an event occurs
    departureTimes = [];
    infoLabels = []; % Keep track of which customers are informed (1) and uninformed (0)
    priorLabels = []; % Keep track of which customers are ordinary (1) and which are priority (0)
    priorFlag = 1; % Current customer event (either arrival or departure), 1 if ordinary, 0 if priority
    uninfBalks = 0; % Number of uninformed customers who choose to not join the queue
    infBalks = 0; % Number of informed customers who choose to not join the queue

    % Simulation Loop
    while currentTime < simulationTime
        % Generate next arrival and service times (Exponential Distribution)
        arrivalInterval = exprnd(1/lambda);
        serviceDuration = exprnd(1/mu);
        if serverFlag == 0
            nextEvent = arrivalInterval;
        else
            if arrivalInterval < serviceDuration
                nextEvent = arrivalInterval;
            else
                nextEvent = serviceDuration;
            end
        end
        if currentTime + nextEvent > simulationTime % Exit the loop if the next arrival/service event exceeds simulation time
            break;
        end

        % If system is empty, next event must be an arrival
        if serverFlag == 0
            currentTime = currentTime + arrivalInterval;
            idleTime = idleTime + arrivalInterval;
            if rand() > gamma % uninformed customer arrives
                if rand() < q % uninformed customer joins
                    serverFlag = 1; % now the server is occupied
                    arrivals = arrivals + 1;
                    arrivalTimes = [arrivalTimes, currentTime];
                    infoLabels = [infoLabels, 0]; % Index with an uninformed customer
                    if rand() < p % purchases priority
                        priorFlag = 0;
                        priorLabels = [priorLabels, 0]; % Index with a priority customer
                    else
                        priorFlag = 1;
                        priorLabels = [priorLabels, 1]; % Index with an ordinary customer
                    end
                else % uninformed customer balks
                    uninfBalks = uninfBalks + 1; 
                end
            else % informed customer arrives (definitely joins without priority)
                serverFlag = 1; % now the server is occupied
                arrivals = arrivals + 1;
                arrivalTimes = [arrivalTimes, currentTime];
                infoLabels = [infoLabels, 1]; % Index with an informed customer
                priorFlag = 1;
                priorLabels = [priorLabels, 1]; % Index with an ordinary customer
            end
        else
            % Compare next arrival and next service completion (this works
            % because of the memoryless property of exponentials)
            if arrivalInterval < serviceDuration % Arrival happens first
                currentTime = currentTime + arrivalInterval;

                if rand() > gamma % uninformed customer arrives
                    if rand() < q % uninformed customer joins
                        priorRand = rand();
                        if priorRand > p && M < maxM % uninformed ORDINARY
                            arrivals = arrivals + 1;
                            M = M + 1;
                            arrivalTimes = [arrivalTimes, currentTime];
                            infoLabels = [infoLabels, 0]; % Index with an uninformed customer at end of queue
                            priorLabels = [priorLabels, 1]; % Index with an ordinary customer at end of queue
                            priorFlag = 1;
                        elseif priorRand <= p && N < maxN % uninformed PRIORITY
                            % For non-preemption priority queue
                            arrivals = arrivals + 1;
                            N = N + 1;
                            arrivalTimes = [arrivalTimes(1:arrivals-M-1), currentTime, arrivalTimes(arrivals-M:end)];
                            infoLabels = [infoLabels(1:arrivals-M-1), 0, infoLabels(arrivals-M:end)]; % Index with an uninformed customer before ordinary queue
                            priorLabels = [priorLabels(1:arrivals-M-1), 0, priorLabels(arrivals-M:end)]; % Index with a priority customer before ordinary queue
                            priorFlag = 0;
                        else
                            uninfBalks = uninfBalks + 1;
                        end
                    else % uninformed customer balks
                        uninfBalks = uninfBalks + 1;
                    end
                else % informed customer arrives
                    if A(M+1, N+1) == 2 && M < maxM % informed ORDINARY
                        arrivals = arrivals + 1;
                        M = M + 1;
                        arrivalTimes = [arrivalTimes, currentTime];
                        infoLabels = [infoLabels, 1]; % Index with an informed customer
                        priorLabels = [priorLabels, 1]; % Index with an ordinary customer
                        priorFlag = 1;

                    elseif A(M+1, N+1) == 1 && N < maxN % informed PRIORITY
                        % For non-preemption priority queue
                        arrivals = arrivals + 1;
                        N = N + 1;
                        arrivalTimes = [arrivalTimes(1:arrivals-M-1), currentTime, arrivalTimes(arrivals-M:end)];
                        infoLabels = [infoLabels(1:arrivals-M-1), 1, infoLabels(arrivals-M:end)]; % Index with an informed customer
                        priorLabels = [priorLabels(1:arrivals-M-1), 0, priorLabels(arrivals-M:end)]; % Index with a priority customer
                        priorFlag = 0;

                    else % queue is too long, so the informed customer balks
                        infBalks = infBalks + 1;
                    end
                end

            else
                % Service completion happens first
                currentTime = currentTime + serviceDuration;

                if priorLabels(length(departureTimes)+1) == 1 % ordinary customer is served
                    priorFlag = 1;
                    if infoLabels(length(departureTimes)+1) == 0 % uninformed ordinary is served
                        totalUninfNorms = totalUninfNorms + 1;
                    else % informed ordinary is served
                        totalInfNorms = totalInfNorms + 1;
                    end
                else % priority customer is served
                    priorFlag = 0;
                    if infoLabels(length(departureTimes)+1) == 0 % uninformed priority is served
                        totalUninfPriors = totalUninfPriors + 1;
                    else % informed priority is served
                        totalInfPriors = totalInfPriors + 1;
                    end
                end

                if M + N == 0
                    serverFlag = 0; % server is idle again
                end

                if serverFlag == 1
                    if priorLabels(length(departureTimes)+2) == 1 % next customer to go into service is ordinary
                        M = max(0, M - 1);
                    else
                        N = max(0, N - 1);
                    end
                end

                departureTimes = [departureTimes, currentTime];
            end
        end

        % Record events for plotting
        timeEvents = [timeEvents, currentTime];
        stateEvents = [stateEvents, serverFlag + M + N];

        if priorFlag == 1 % ordinary customer either arrives or leaves
            normTimes = [normTimes, currentTime];
            normState = [normState, M];
        else
            priorTimes = [priorTimes, currentTime];
            priorState = [priorState, N];
        end
    end

    % for debugging
    timeEvents;
    stateEvents;
    arrivalTimes;
    departureTimes;
    priorLabels;

    % Calculating the average queue length (area under plot)
    totalTime = 0;
    i = 1;
    while i < length(stateEvents)
        totalTime = totalTime + (stateEvents(i) * (timeEvents(i+1)-timeEvents(i)));
        i = i+1;
    end
    averageLength = totalTime / simulationTime;

    % Calculating the average queue length (area under plot) for ordinary and priority queues
    totalNormTime = 0;
    i = 1;
    while i < length(normState)
        totalNormTime = totalNormTime + (normState(i) * (normTimes(i+1)-normTimes(i)));
        i = i+1;
    end
    averageNormLength = totalNormTime / simulationTime;

    totalPriorTime = 0;
    i = 1;
    while i < length(priorState)
        totalPriorTime = totalPriorTime + (priorState(i) * (priorTimes(i+1)-priorTimes(i)));
        i = i+1;
    end
    averagePriorLength = totalPriorTime / simulationTime;

    % Calculating the proportion of time spent idle
    propIdle = idleTime / simulationTime;

    % Calculating the average (sojourn) time for a customer in the system
    arrivalTimesFixed = arrivalTimes(1:length(departureTimes)); % Match the arrivals with departures, to consider only customers who finish service
    customerWait = departureTimes - arrivalTimesFixed; % Each individual customer's time in system
    averageCustomerTime = sum(customerWait) / length(arrivalTimesFixed);

    % Calculating the average sojourn time for ordinary (1) and priority (0) customers separately
    priorLabelsFixed = priorLabels(1:length(departureTimes));
    normWait = customerWait .* priorLabelsFixed;
    priorWait = customerWait .* (1-priorLabelsFixed);
    averagePriorTime = sum(priorWait) / (totalUninfPriors + totalInfPriors);
    averageNormTime = sum(normWait) / (totalUninfNorms + totalInfNorms);

    % Calculating the average sojourn time for uninformed (0) and informed (1) customers separately
    infoLabelsFixed = infoLabels(1:length(departureTimes));
    uninfWait = customerWait .* (1-infoLabelsFixed);
    infWait = customerWait .* infoLabelsFixed;
    averageUninfTime = sum(uninfWait) / (totalUninfNorms + totalUninfPriors);
    averageInfTime = sum(infWait) / (totalInfNorms + totalInfPriors);

    % Calculating the average sojourn time for the 4 types of customers separately
    uninfNormWait = customerWait .* priorLabelsFixed .* (1-infoLabelsFixed);
    infNormWait = customerWait .* priorLabelsFixed .* infoLabelsFixed;
    uninfPriorWait = customerWait .* (1-priorLabelsFixed) .* (1-infoLabelsFixed);
    infPriorWait = customerWait .* (1-priorLabelsFixed) .* infoLabelsFixed;
    avgUninfNormTime = sum(uninfNormWait) / totalUninfNorms;
    avgInfNormTime = sum(infNormWait) / totalInfNorms;
    avgUninfPriorTime = sum(uninfPriorWait) / totalUninfPriors;
    avgInfPriorTime = sum(infPriorWait) / totalInfPriors;


    % Calculating the proportion of customers who actually join the system,
    % instead of balking
    propJoin = (totalUninfNorms + totalUninfPriors + totalInfNorms + totalInfPriors) / (totalUninfNorms + totalUninfPriors + totalInfNorms + totalInfPriors + uninfBalks + infBalks);

    % Proportion of informed and uninformed customers who join
    propUninfJoin = (totalUninfNorms + totalUninfPriors) / (totalUninfNorms + totalUninfPriors + uninfBalks);
    propInfJoin = (totalInfNorms + totalInfPriors) / (totalInfNorms + totalInfPriors + infBalks);

    % Calculating the proportion of customers who purchased priority, out of
    % those who were served
    propPrior = (totalUninfPriors + totalInfPriors) / (totalUninfNorms + totalInfNorms + totalUninfPriors + totalInfPriors);
    propUninfPrior = totalUninfPriors / (totalUninfNorms + totalUninfPriors);
    propInfPrior = totalInfPriors / (totalInfNorms + totalInfPriors);

    % Calculating the social welfare (sum of customer utilities)
    avgWelfare = (R*length(departureTimes) - P*(totalInfPriors + totalUninfPriors) - C*sum(customerWait))/simulationTime;

    % Plotting the sample path
    if plot == 1 && j == 1
        figure;
        hold on;
        stairs(timeEvents, stateEvents, 'LineWidth', 1.5); % total number of customers
        stairs(normTimes, normState, 'LineWidth', 1.5); % number of ordinary customers
        stairs(priorTimes, priorState, 'LineWidth', 1.5); % number of priority customers
        title_str = sprintf('$\\mathbf{\\lambda}$ = %.1f', lambda);
        title(title_str, "FontSize", 30, 'interpreter', 'latex');
        ax = gca;
        ax.XAxis.FontSize = 13;
        ay = gca;
        ay.YAxis.FontSize = 13;
        xlabel('Time (minutes)', "FontSize", 20);
        ylabel('Number of Customers in System', "FontSize", 20);
        legend('Total', 'Ordinary', 'Priority', 'FontSize', 18);
        grid on;
    end

    trialResults = [averageLength, averageNormLength, averagePriorLength, propIdle, averageCustomerTime, averageNormTime, averagePriorTime, averageUninfTime, averageInfTime, avgUninfNormTime, avgInfNormTime, avgUninfPriorTime, avgInfPriorTime, propJoin, propUninfJoin, propInfJoin, propPrior, propUninfPrior, propInfPrior, avgWelfare];
    mixedPriorResults(end+1, :) = trialResults;
end
mixedPriorResults; % all results
[~, ~, ci] = ttest(mixedPriorResults);
means = mean(mixedPriorResults, 1);
ciLower = ci(1:2:end);
ciUpper = ci(2:2:end);
end