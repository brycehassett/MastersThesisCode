% This function computes the equilibrium strategy (q, p) for the 
% fully unobservable priority queue, from Section 4.1.1.
% By Bryce Hassett

function [q, p] = unobsPriorEquil(lambda, mu, R, C, P)

% Using Wang et al (2019) to calculate the equilibrium joining probability,
% q, and the probability of purchasing priority, p.
rho = lambda/mu; % System load
vR = R*mu/C; % Service reward relative to average waiting cost for a service cycle
vP = P*mu/C; % Priority premium relative to average waiting cost for a service cycle

rhoStar = (sqrt(vP^2 + 4*vP) - vP)/2; % for notation
rhoDash = (sqrt(vP))/(sqrt(vP)+1); % for notation

if rho < 1
    if vP == 0
        p = 1;
        if (1 < vR) && (vR < 1/(1-rho))
            effArrival = mu - mu/vR; % effective arrival rate
        else
            effArrival = lambda;
        end
    elseif (0 < vP) && (vP <= rho^2/(1-rho))
        if (1 < vR) && (vR <= rhoStar + 1 + vP)
            p = 0;
            effArrival = mu - mu/vR;
        elseif (rhoStar+1+vP < vR) && (vR <= 1/(1-rhoDash)+vP)
            p = (vR-1)/vP - 1/(vR-vP-1);
            effArrival = vP*mu/(vR-1);
        elseif (1/(1-rhoDash)+vP < vR) && (vR <= 1/(1-rho)+vP)
            p = 1;
            effArrival = mu - mu/(vR-vP);
        else
            p = 1;
            effArrival = lambda;
        end
    else
        if (1 < vR) && (vR <= 1/(1-rho))
            p = 0;
            effArrival = mu - mu/vR;
        else
            p = 0;
            effArrival = lambda;
        end
    end
else
    if vP == 0
        p = 1;
        effArrival = mu - mu/vR;
    else
        if (1 < vR) && (vR <= rhoStar+1+vP)
            p = 0;
            effArrival = mu - mu/vR;
        elseif (rhoStar+1+vP < vR) && (vR <= 1/(1-rhoDash)+vP)
            p = (vR-1)/vP - 1/(vR-vP-1);
            effArrival = vP*mu/(vR-1);
        else
            p = 1;
            effArrival = mu - mu/(vR-vP);
        end
    end
end

% For debugging
p;
effArrival;

q = effArrival / lambda;