% This function verifies that the strategy matrix A produced by 
% mipqInfEquilFunc.m is the best response to itself, and 
% corrects it if it is not.
% By Bryce Hassett

function [A, bestResponse, wrongStates] = mipqBestResponse(lambda, mu, gamma, R, C, P, q, p, A, maxTime, trials, maxM, maxN)
M = 0;
N = 0;

wrongStates = []; % set of states where the strategy matrix is not a best response to itself

% Testing if this is a best response to itself
bestResponse = 1; % if this is set to zero at any point, it means there is an inconsistency!
while N < maxN
    while M < maxM
        state = [M, N];
        expWait = mipqInfStateSim(lambda, mu, gamma, q, p, A, M, N, maxTime, trials);
        state;
        A(M+1,N+1);
        ordUtil = R - C*expWait;
        priorUtil = R - P - (N+2)*C/mu;

        if ordUtil < -0.1 && priorUtil < -0.1 && A(M+1, N+1) ~= 0
            ordUtil = R - C*expWait;
            priorUtil = R - P - (N+2)*C/mu;
            %disp("Not a best response! (" + M + ", " + N + " should balk)")
            bestResponse = 0;
            wrongStates(end+1, :) = [M,N];
            A(M+1, N+1) = 0;

        elseif ordUtil > priorUtil && ordUtil > 0.1 && A(M+1, N+1) ~= 2
            ordUtil = R - C*expWait;
            priorUtil = R - P - (N+2)*C/mu;
            %disp("Not a best response! (" + M + ", " + N + " should ord)")
            bestResponse = 0;
            wrongStates(end+1, :) = [M,N];
            A(M+1, N+1) = 2;

        elseif ordUtil < priorUtil && priorUtil > 0.1 && A(M+1, N+1) ~= 1
            ordUtil = R - C*expWait;
            priorUtil = R - P - (N+2)*C/mu;
            %disp("Not a best response! (" + M + ", " + N + " should prior)")
            bestResponse = 0;
            wrongStates(end+1, :) = [M,N];
            A(M+1, N+1) = 1;
        end
        
        % Speeding up the check (using Lemma 5.1)
        if ordUtil < -0.1 && priorUtil < -0.1 && A(M+1, N+1) == 0
            A(M+2:end, N+1) = 0;
            break; % if balking is best when M ordinary, it is best when >M ordinary
        elseif priorUtil > ordUtil && A(M+1, N+1) == 1
            A(M+2:end, N+1) = 1;
            break; % if priority is best when M ordinary, it is best when >M ordinary
        end
        
        M = M + 1; % Next try state (1, 0)
    end
    M = 0;
    N = N + 1;
end