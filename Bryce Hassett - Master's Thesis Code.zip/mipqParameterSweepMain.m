% This function controls and calls the parameter sweep function, 
% mipqParameterSweep.m.
% By Bryce Hassett

clear;
clc;
rng(1); % because of the resuming mechanic, this does not matter

% Parameters to sweep
rhoVals = [0.2 0.5 0.9 1 1.1 1.5 2 2.5];
muVals = 1;
gammaVals = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
RVals = [5 10];
CVals = 1;
PVals = [0 2 5];

% Simulation / equilibrium parameters
trials = 100;
runs = 100;
maxTime = 100;
simulationTime = 10000;
plots = 0;

% size of system depends on rho, so multiply this number by rho
maxMMult = 15;
maxNMult = 15;

outputFile = 'MIPQ_parameter_sweep.csv'; % output file

saveEvery = 1; % how often to save

% Run the parameter sweep
results = mipqParameterSweep(rhoVals, muVals, gammaVals, RVals, CVals, PVals, trials, runs, maxTime, maxMMult, maxNMult, simulationTime, plots, outputFile, saveEvery);