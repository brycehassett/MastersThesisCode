% This function simulates the expected waiting time for a tagged 
% informed customer who joins without priority, for every possible state 
% they could observe on arrival.
% By Bryce Hassett

function expWait = mipqInfStateSim(lambda, mu, gamma, q, p, A, initM, initN, maxTime, trials)

waits = [];
[maxM, maxN] = size(A);
maxM = maxM - 1;
maxN = maxN - 1;

for j = 1:trials
    % Initialization
    currentTime = 0;
    serverFlag = 1; % 0 if server is idle, 1 if server is busy
    position = initM + initN + 1; % Initial position of tagged ordinary customer in queue (excluding server)
    
    % M and N are the numbers of ordinary and priority customers in the queue
    M = initM + 1; % tagged customer joins as ordinary
    N = initN;

    timeEvents = 0; % Times when either an arrival or departure occurs
    stateEvents = 0; % Number of customers in system when an event occurs
    arrivals = 0; % Number of customers who arrive at the queue
    departureTimes = [];

    % Simulation Loop
    while currentTime < maxTime
        
        % Generate next arrival and service times (Exponential Distribution)
        arrivalInterval = exprnd(1/lambda);
        serviceDuration = exprnd(1/mu);
        if arrivalInterval < serviceDuration
            nextEvent = arrivalInterval;
        else
            nextEvent = serviceDuration;
        end
        if currentTime + nextEvent > maxTime % Exit the loop if the time exceeds the maximum time
            currentTime = maxTime;
            break;
        end

        % Compare next arrival and next service completion (this works
        % because of the memoryless property of exponentials)
        if arrivalInterval < serviceDuration % Arrival happens first
            currentTime = currentTime + arrivalInterval;

            if rand() > gamma % uninformed customer arrives
                if rand() < q % uninformed customer joins
                    arrivals = arrivals + 1;
                    if rand() > p && M < maxM % uninformed ORDINARY
                        M = M + 1;
                    elseif rand() <= p && N < maxN % uninformed PRIORITY
                        % For non-preemption priority queue
                        N = N + 1;
                        position = position + 1;
                    end
                end
            else % informed customer arrives
                if A(M+1, N+1) == 2 && M < maxM % informed ORDINARY
                    arrivals = arrivals + 1;
                    M = M + 1;

                elseif A(M+1, N+1) == 1 && N < maxN % informed PRIORITY
                    % For non-preemption priority queue
                    arrivals = arrivals + 1;
                    N = N + 1;
                    position = position + 1;
                end
            end

        else
            % Service completion happens first
            currentTime = currentTime + serviceDuration;
            if position == 1
                % tagged customer will be served now
                bonusServiceDuration = exprnd(1/mu);
                currentTime = currentTime + bonusServiceDuration; % the tagged customer being served
                departureTimes = [departureTimes, currentTime];
                break; % simulation done
            end

            position = position - 1;

            if N == 0 % next customer to go into service is ordinary
                M = max(0, M - 1);
            else
                N = max(0, N - 1);
            end

            departureTimes = [departureTimes, currentTime];
        end
    end

    % Calculating the average (sojourn) time for a customer in the system
    waits = [waits, currentTime];
end
expWait = mean(waits);