% A simple M/M/1 queue simulation, used as a foundation for the 
% strategic queueing models. 
% By Bryce Hassett

function output = mm1(lambda, mu, simulationTime)
% Initialization
currentTime = 0;
customersInSystem = 0;
timeEvents = 0; % Times when either an arrival or departure occurs
stateEvents = 0; % Number of customers in system when an event occurs
idleTime = 0; % Keep track of idle time
arrivals = 0; % Number of customers who arrive at the queue
arrivalTimes = [];
departureTimes = [];

% Simulation Loop
while currentTime < simulationTime
    % Generate next arrival and service times (Exponential Distribution)
    arrivalInterval = exprnd(1/lambda); % Argument is mean, so reciprocal
    serviceDuration = exprnd(1/mu);
    if currentTime + arrivalInterval > simulationTime
        break; % Exit the loop if the next arrival exceeds simulation time
    end
    if currentTime + serviceDuration > simulationTime
        break; % Exit the loop if the next service occurs after the end of simulation
    end

    % If system is empty, next event must be an arrival
    if customersInSystem == 0
        idleTime = idleTime + arrivalInterval;
        currentTime = currentTime + arrivalInterval;
        customersInSystem = 1;
        arrivals = arrivals + 1;
        arrivalTimes = [arrivalTimes, currentTime];
    else
        % Compare next arrival and next service completion (this works 
        % because of the memoryless property of exponentials)
        if arrivalInterval < serviceDuration
            % Arrival happens first
            currentTime = currentTime + arrivalInterval;
            customersInSystem = customersInSystem + 1;
            arrivals = arrivals + 1;
            arrivalTimes = [arrivalTimes, currentTime];
        else
            % Service completion happens first
            currentTime = currentTime + serviceDuration;
            customersInSystem = customersInSystem - 1;
            departureTimes = [departureTimes, currentTime];
        end
    end
    
    % Record events for plotting
    timeEvents = [timeEvents, currentTime];
    stateEvents = [stateEvents, customersInSystem];
end

% for debugging
timeEvents;
stateEvents;
arrivalTimes;
departureTimes;

% Calculating the average queue length (area under plot)
totalTime = 0;
i = 1;
while i < length(stateEvents)
    totalTime = totalTime + (stateEvents(i) * (timeEvents(i+1)-timeEvents(i)));
    i = i+1;
end
averageLength = totalTime / simulationTime;

% Calculating the average (sojourn) time for a customer in the system
arrivalTimesFixed = arrivalTimes(1:length(departureTimes)); % Match the arrivals with departures, to consider only customers who finish service
customerWait = departureTimes - arrivalTimesFixed; % Each individual customer's time in system
averageCustomerTime = sum(customerWait) / length(arrivalTimesFixed);

% Calculating the proportion of time spent idle
propIdle = idleTime / simulationTime;

% Plotting the sample path
figure;
stairs(timeEvents, stateEvents, 'LineWidth', 1.5);
title_str = sprintf('M/M/1 Queue Simulation (lambda = %d, mu = %d)', lambda, mu);
title(title_str, "FontSize", 24);
xlabel('Time (minutes)', "FontSize", 24);
ylabel('Number of Customers in System', "FontSize", 24);
grid on;

output = [averageLength, averageCustomerTime, propIdle];
end