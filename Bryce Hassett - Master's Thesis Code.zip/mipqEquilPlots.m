% This function generates the plots for the equilibrium strategies 
% of the MIPQ in Section 5.3.
% By Bryce Hassett

clc;
clear;
close all;
rng(1);

fullData = readtable('MIPQ_parameter_sweep.csv'); % to not accidentally overwrite the csv

% List of possible parameter values in the data
% rhoVals = [0.2 0.5 0.9 1 1.1 1.5 2 2.5];
% muVals = 1;
% gammaVals = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
% RVals = [5 10];
% CVals = 1;
% PVals = [0 2 5];

mu = 1;
C = 1;
simulationTime = 1000;
trials = 100;
plots = 0;

% Plotting equilibrium (q,p) for various gamma
lambdaTargets = [0.9, 1.5, 2, 2.5];
RTarget = 10;
PTargets = [0, 2, 5];

lims = [0,1]; % bounds of the plots

%%
% Plotting for various lambda (figure for each P)
figure; % q
t = tiledlayout(1, length(PTargets), 'TileSpacing', 'Compact');
for j = 1:length(PTargets)
    nexttile;
    hold on;
    for i = 1:length(lambdaTargets)
        targetRows = (fullData.lambda == lambdaTargets(i)) & (fullData.R == RTarget) & (fullData.P == PTargets(j)) & (fullData.gamma < 1);
        filteredData = fullData(targetRows, :);
        plot(filteredData.gamma, filteredData.qEquil, 'o-', 'LineWidth', 2);
        xlim(lims);
        ylim(lims);
    end
    title_str = sprintf('P = %d', PTargets(j));
    title(title_str, "FontSize", 20);
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Equilibrium joining probability, q', "FontSize", 20, 'Interpreter', 'latex');
legend("$\lambda$ = " + lambdaTargets(1), "$\lambda$ = " + lambdaTargets(2), "$\lambda$ = " + lambdaTargets(3), "$\lambda$ = " + lambdaTargets(4) + " ", 'Interpreter', 'latex', 'FontSize', 20, 'Location', 'eastoutside');
title_str = sprintf('Effect of load on joining equilibrium (R = %d)', RTarget);
title(t, title_str, "FontSize", 25);


figure; % p
t = tiledlayout(1, length(PTargets), 'TileSpacing', 'Compact');
for j = 1:length(PTargets)
    nexttile;
    hold on;
    for i = 1:length(lambdaTargets)
        targetRows = (fullData.lambda == lambdaTargets(i)) & (fullData.R == RTarget) & (fullData.P == PTargets(j)) & (fullData.gamma < 1);
        filteredData = fullData(targetRows, :);
        plot(filteredData.gamma, filteredData.pEquil, 'o-', 'LineWidth', 2);
        xlim(lims);
        ylim(lims);
    end
    title_str = sprintf('P = %d', PTargets(j));
    title(title_str, "FontSize", 20);
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Equilibrium priority probability, p', "FontSize", 20, 'Interpreter', 'latex');
legend("$\lambda$ = " + lambdaTargets(1), "$\lambda$ = " + lambdaTargets(2), "$\lambda$ = " + lambdaTargets(3), "$\lambda$ = " + lambdaTargets(4) + " ", 'Interpreter', 'latex', 'FontSize', 20, 'Location', 'eastoutside');
title_str = sprintf('Effect of load on priority equilibrium (R = %d)', RTarget);
title(t, title_str, "FontSize", 25);




% Plotting for various P (figure for each lambda)
figure; % q
t = tiledlayout(2, 2, 'TileSpacing', 'Compact');
for j = 1:length(lambdaTargets)
    nexttile;
    hold on;
    for i = 1:length(PTargets)
        targetRows = (fullData.lambda == lambdaTargets(j)) & (fullData.R == RTarget) & (fullData.P == PTargets(i)) & (fullData.gamma < 1);
        filteredData = fullData(targetRows, :);
        plot(filteredData.gamma, filteredData.qEquil, 'o-', 'LineWidth', 2);
        xlim(lims);
        ylim(lims);
    end
    title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(j));
    title(title_str, "FontSize", 20, 'interpreter', 'latex');
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Equilibrium joining probability, q', "FontSize", 20, 'Interpreter', 'latex');
legend("P = " + PTargets(1), "P = " + PTargets(2), "P = " + PTargets(3) + " ", 'FontSize', 20, 'Location', 'eastoutside');
title_str = sprintf('Effect of priority fee on joining equilibrium (R = %d)', RTarget);
title(t, title_str, "FontSize", 25);


figure; % p
t = tiledlayout(2, 2, 'TileSpacing', 'Compact');
for j = 1:length(lambdaTargets)
    nexttile;
    hold on;
    for i = 1:length(PTargets)
        targetRows = (fullData.lambda == lambdaTargets(j)) & (fullData.R == RTarget) & (fullData.P == PTargets(i)) & (fullData.gamma < 1);
        filteredData = fullData(targetRows, :);
        plot(filteredData.gamma, filteredData.pEquil, 'o-', 'LineWidth', 2);
        xlim(lims);
        ylim(lims);
    end
    title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(j));
    title(title_str, "FontSize", 20, 'interpreter', 'latex');
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Equilibrium priority probability, p', "FontSize", 20, 'Interpreter', 'latex');
legend("P = " + PTargets(1), "P = " + PTargets(2), "P = " + PTargets(3) + " ", 'FontSize', 20, 'Location', 'eastoutside');
title_str = sprintf('Effect of priority fee on priority equilibrium (R = %d)', RTarget);
title(t, title_str, "FontSize", 25);

%%
% Plotting joining proportion of both uninformed and informed customers
%PTargets = 2; % one figure for each P

for k = 1:length(PTargets)
    figure; % q
    t = tiledlayout(2, 2, 'TileSpacing', 'Compact');
    for i = 1:length(lambdaTargets)
        nexttile;
        hold on;
        targetRows = (fullData.lambda == lambdaTargets(i)) & (fullData.R == RTarget) & (fullData.P == PTargets(k));
        filteredData = fullData(targetRows, :);
        InfJoinNeg = filteredData.propInfJoin - filteredData.propInfJoinLower;
        InfJoinPos = filteredData.propInfJoinUpper - filteredData.propInfJoin;
        filtered2Rows = (filteredData.gamma < 1);
        filtered2 = filteredData(filtered2Rows, :);
        plot(filtered2.gamma, filtered2.qEquil, 'o-', 'LineWidth', 2);
        errorbar(filteredData.gamma, filteredData.propInfJoin, InfJoinNeg, InfJoinPos, 'o-', 'LineWidth', 2);

        % Mixed FCFS Queue
        meanPropUninf = [];
        meanPropInf = [];
        lowerPropInf = [];
        upperPropInf = [];
        gammas = 0:0.1:1;
        for j = 1:length(gammas)
            gamma = gammas(j);
            [N, q] = mixedEquil(lambdaTargets(i), mu, RTarget, C, gamma);
            [mixedAvg, mixedCILow, mixedCIHigh] = mixedQueue(lambdaTargets(i), mu, RTarget, C, gamma, q, N, simulationTime, trials, plots);

            meanPropUninf = [meanPropUninf, mixedAvg(6)];

            meanPropInf = [meanPropInf, mixedAvg(7)];
            lowerPropInf = [lowerPropInf, mixedCILow(7)];
            upperPropInf = [upperPropInf, mixedCIHigh(7)];

            disp(['Finished ', num2str(j), ' of ', num2str(length(gammas))])
        end
        propInfNeg = meanPropInf - lowerPropInf;
        propInfPos = upperPropInf - meanPropInf;
        plot(gammas(1:end-1), meanPropUninf(1:end-1), '-o', 'LineWidth', 2, 'LineStyle', ':')
        errorbar(gammas, meanPropInf, propInfNeg, propInfPos, '-o', 'LineWidth', 2, 'LineStyle', ':')


        xlim(lims);
        ylim(lims);
        title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(i));
        title(title_str, "FontSize", 20, 'interpreter', 'latex');
        ax = gca;
        ax.XAxis.FontSize = 13;
        ay = gca;
        ay.YAxis.FontSize = 13;
        grid on;
        hold off;
    end
    xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
    ylabel(t, 'Equilibrium joining probability, q', "FontSize", 20, 'Interpreter', 'latex');
    legend("Uninformed (MIPQ)", "Informed (MIPQ)", "Uninformed (FCFS)", "Informed (FCFS)", 'FontSize', 20, 'Location', 'northeastoutside');
    title_str = sprintf('Joining proportions for uninformed and informed customers (P = %d, R = %d)', PTargets(k), RTarget);
    title(t, title_str, "FontSize", 25);
end

%% Dsiplaying the strategy matrix for informed customers
% rhoVals = [0.2 0.5 0.9 1 1.1 1.5 2 2.5];
lambdaTargets = 0.2;
maxM = 10;
maxN = 10;
maxTime = 100;

RTargets = 10;
PTargets = [0,2,5];



t = tiledlayout(length(PTargets), 13, 'TileSpacing', 'Compact');
row_labels = {"P = 0", "P = 2", "P = 5"};
for P = 1:length(PTargets)
    targetRows = (fullData.lambda == lambdaTargets) & (fullData.R == RTarget) & (fullData.P == PTargets(P)) & (fullData.gamma > 0);
    filteredData = fullData(targetRows, :);
    for gammas = 0.1:0.3:1
        targetRows2 = (filteredData.gamma == gammas);
        filteredData2 = filteredData(targetRows2, :);
        nexttile([1,3]);
        hold on;
        A = mipqInfEquilFunc(lambdaTargets, mu, gammas, RTargets, C, PTargets(P), filteredData2.qEquil, filteredData2.pEquil, trials, maxTime, maxM, maxN);
        imagesc([0, size(A,2)-1], [0, size(A,1)-1], A');
        axis tight;

        clim([-0.5, 2.5]);
        customMap = [
            1, 0, 0;  % Red for 0
            1, 1, 0;  % Yellow for 1
            0, 1, 0   % Green for 2
            ];
        colormap(customMap);

        [rows, cols] = size(A);
        ax = gca;
        ax.XTick = 0:cols-1;
        ax.YTick = 0:rows-1;
        ax.TickLength = [0 0];
        % remove the axis labels
        %xticks([]) 
        %yticks([]) 

        hold on;
        % Draw vertical border lines
        for x = -0.5 : 1 : cols-0.5
            line([x, x], [-0.5, rows-0.5], 'Color', [0, 0, 0], 'LineWidth', 1.5);
        end

        % Draw horizontal border lines
        for y = -0.5 : 1 : rows-0.5
            line([-0.5, cols-0.5], [y, y], 'Color', [0, 0, 0], 'LineWidth', 1.5);
        end
        hold off;
        if P == 1
            title_str = sprintf('$\\mathbf{\\gamma}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', gammas);
            title(title_str, "FontSize", 20, 'interpreter', 'latex');
        end
    end
    ax_label = nexttile; 
    axis(ax_label, 'off'); % Hide the plot box and ticks
    text(ax_label, 0.1, 0.5, row_labels{P}, ...
        'FontSize', 20, 'FontWeight', 'bold', ...
        'VerticalAlignment', 'middle');
end

xlabel(t, 'Number of ordinary customers, M', "FontSize", 20)
ylabel(t, 'Number of priority customers, N', "FontSize", 20)
title_str = sprintf('Strategy matrix for informed customers (R = %d, ${\\lambda}$ = %.1f)', RTargets, lambdaTargets);
title(t, title_str, "FontSize", 25, 'interpreter', 'latex');