% This function controls and calls all of the parameter sweep functions 
% for the 5 core queueing models.
% By Bryce Hassett

clear;
clc;
rng(1); % if the resuming mechanic is used, this does not matter

% Parameters to sweep
rhoVals = [0.2 0.5 0.9 1 1.1 1.5 2 2.5];
muVals = 1;
gammaVals = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
RVals = [5 10];
CVals = 1;
PVals = [0 2 5];

% Simulation / equilibrium parameters
trials = 100;
runs = 100;
maxTime = 100;
simulationTime = 10000;
plots = 0;

% Output files (one for each model)
outputFileUnobsFCFS = 'UnobsFCFS_parameter_sweep.csv';
outputFileObsFCFS = 'ObsFCFS_parameter_sweep.csv';
outputFileMixedFCFS = 'MixedFCFS_parameter_sweep.csv';
outputFileUnobsPrior = 'UnobsPrior_parameter_sweep.csv';
outputFileObsPrior = 'ObsPrior_parameter_sweep.csv';

saveEvery = 1; % how often to save

% Run sweeps
resultsUnobsFCFS = unobsFCFSParameterSweep(rhoVals, muVals, gammaVals, RVals, CVals, PVals, trials, runs, maxTime, simulationTime, plots, outputFileUnobsFCFS, saveEvery);
resultsObsFCFS = obsFCFSParameterSweep(rhoVals, muVals, gammaVals, RVals, CVals, PVals, trials, runs, maxTime, simulationTime, plots, outputFileObsFCFS, saveEvery);
resultsMixedFCFS = mixedFCFSParameterSweep(rhoVals, muVals, gammaVals, RVals, CVals, PVals, trials, runs, maxTime, simulationTime, plots, outputFileMixedFCFS, saveEvery);
resultsUnobsPrior = unobsPriorParameterSweep(rhoVals, muVals, gammaVals, RVals, CVals, PVals, trials, runs, maxTime, simulationTime, plots, outputFileUnobsPrior, saveEvery);
resultsObsPrior = obsPriorParameterSweep(rhoVals, muVals, gammaVals, RVals, CVals, PVals, trials, runs, maxTime, simulationTime, plots, outputFileObsPrior, saveEvery);