% This function computes all equilibrium strategies for the 
% mixed information priority queue, (A, q, p), from Section 5.2.
% By Bryce Hassett

function [qEquil,pEquil,AEquil, internalFound] = mipqFullEquil(lambda, mu, gamma, R, C, P, trials, runs, maxTime, maxM, maxN)

qEquil = [];
pEquil = [];
AEquil = [];
internalFound = 0;

options = optimset( ...
    'Display','off', ...
    'TolX',1e-2, ...
    'MaxIter',30, ...
    'MaxFunEvals',50);

if gamma == 1 % no uninformed customers
    %disp("No uninformed customers")
    qEquil = [qEquil, 0];
    pEquil = [pEquil, 0];
    AEquil = [AEquil, mipqInfEquilFunc(lambda, mu, gamma, R, C, P, 0, 0, trials, maxTime, maxM, maxN)];
    return
end

if gamma == 0 % only uninformed customers
    %disp("Only uninformed customers")
    [q,p] = unobsPriorEquil(lambda, mu, R, C, P); % reduces to unobservable priority queue
    qEquil = [qEquil, q];
    pEquil = [pEquil, p];
    AEquil = zeros(maxM+1,maxN+1);
    return
end

% Checking if q = 0 is an equilibrium
q = 0;
p = 0; % doesn't matter, since no uninformed customers join anyway
utilities00 = mipqUninfUtil_Corner(lambda, mu, gamma, R, C, P, q, p, trials, runs, maxTime, maxM, maxN);
if utilities00(1) <= 0 && utilities00(2) <= 0 % (0,0) is an equilibrium
    A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);
    %disp("q = 0 is an equilibrium")
    qEquil = [qEquil, q];
    pEquil = [pEquil, p];
    AEquil = [AEquil, A];
else
    %disp("q = 0 is NOT a equilibrium")
end
%disp('------------------')

% Check if q = 1, p = 0 is an equilibrium
q = 1;
p = 0; % doesn't matter, since no uninformed customers join anyway
utilities10 = mipqUninfUtil_Corner(lambda, mu, gamma, R, C, P, q, p, trials, runs, maxTime, maxM, maxN);
if utilities10(1) >= 0 && utilities10(1) >= utilities10(2) % (1,0) is an equilibrium
    A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);
    %disp("(1,0) is an equilibrium")
    qEquil = [qEquil, q];
    pEquil = [pEquil, p];
    AEquil = [AEquil, A];
else
    %disp("(1,0) is NOT an equilibrium")
end
%disp('------------------')

% Check if q = 1, p = 1 is an equilibrium
q = 1;
p = 1;
utilities11 = mipqUninfUtil_Corner(lambda, mu, gamma, R, C, P, q, p, trials, runs, maxTime, maxM, maxN);
if utilities11(2) >= 0 && utilities11(1) <= utilities11(2) % (1,1) is an equilibrium
    A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);
    %disp("(1,1) is an equilibrium")
    qEquil = [qEquil, q];
    pEquil = [pEquil, p];
    AEquil = [AEquil, A];
else
    %disp("(1,1) is NOT an equilibrium")
end
%disp('------------------')

% Checking equilibrium for p = 0 and q between 0 and 1
p = 0;

if utilities00(1) * utilities10(1) < 0
    try
        [q,fval,exitflag,output] = fzero(@(q) mipqUninfUtil_FixedP(q, lambda, mu, gamma, R, C, P, p, trials, runs, maxTime, maxM, maxN),[0,1],options);
        utils = mipqUninfUtil_Corner(lambda, mu, gamma, R, C, P, q, p, trials, runs, maxTime, maxM, maxN); % checking that the utility for prior is also negative
    catch ME
        q = NaN;
        exitflag = 0;
    end
else 
    exitflag = 0; % no equilibrium
end

if exitflag == 1 && utils(2) < 0.1 % add some wiggle room
    A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);
    %disp("Equilibrium at q = " + q + " and p = 0")
    qEquil = [qEquil, q];
    pEquil = [pEquil, p];
    AEquil = [AEquil, A];
else
    %disp("No equilibrium when p = 0 and 0 < q < 1")
end
%disp('------------------')


% Checking equilibrium for p = 1 and q between 0 and 1
p = 1; % always buy priority
if utilities00(2) * utilities11(2) < 0
    try
        [q,fval,exitflag,output] = fzero(@(q) mipqUninfUtil_FixedP(q, lambda, mu, gamma, R, C, P, p, trials, runs, maxTime, maxM, maxN),[0,1],options);
        utils = mipqUninfUtil_Corner(lambda, mu, gamma, R, C, P, q, p, trials, runs, maxTime, maxM, maxN); % checking that the utility for ordinary is also negative
    catch ME
        q = NaN;
        exitflag = 0;
    end
else 
    exitflag = 0; % no equilibrium
end

if exitflag == 1 && utils(1) < 0.1 % add some wiggle room
    A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);
    %disp("Equilibrium at q = " + q + " and p = 1")
    qEquil = [qEquil, q];
    pEquil = [pEquil, p];
    AEquil = [AEquil, A];
else
    %disp("No equilibrium when p = 1 and 0 < q < 1")
end
%disp('------------------')


% Checking equilibrium for q = 1 and p between 0 and 1
q = 1;
if mipqUninfUtil_FixedQ(0, lambda, mu, gamma, R, C, P, q, trials, runs, maxTime, maxM, maxN) * mipqUninfUtil_FixedQ(1, lambda, mu, gamma, R, C, P, q, trials, runs, maxTime, maxM, maxN) < 0
    try
        [p,fval,exitflag,output] = fzero(@(p) mipqUninfUtil_FixedQ(p, lambda, mu, gamma, R, C, P, q, trials, runs, maxTime, maxM, maxN),[0,1],options);
        utils = mipqUninfUtil_Corner(lambda, mu, gamma, R, C, P, q, p, trials, runs, maxTime, maxM, maxN); % checking that the utility for ordinary is also positive
    catch ME
        p = NaN;
        exitFlag = 0;
    end
else 
    exitflag = 0; % no equilibrium
end

if exitflag == 1 && utils(1) > -0.1 % add some wiggle room
    A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);
    %disp("Equilibrium at q = 1 and p = " + p)
    qEquil = [qEquil, q];
    pEquil = [pEquil, p];
    AEquil = [AEquil, A];
else
    %disp("No equilibrium when q = 1 and 0 < p < 1")
end
%disp('------------------')


% Checking internal equilibrium for q and p between 0 and 1
% bounds for q and p
lb = [0,0];
ub = [1,1];
x0 = [0.5,0.5]; % initial guess

% Making the solver use larger perturbations (10^-2) (for speed)
options = optimoptions('lsqnonlin',...
    'Display','off',...
    'OptimalityTolerance',1e-1,...
    'FiniteDifferenceType','forward',...
    'FiniteDifferenceStepSize',1e-2,...
    'FunctionTolerance',1e-3,...
    'StepTolerance',1e-3,...
    'MaxIter',30, ...
    'MaxFunEvals',50);

try
    [x,resnorm,residual, exitflag] = lsqnonlin(@(x) mipqUninfUtilFunc(x, lambda, mu, gamma, R, C, P, trials, runs, maxTime, maxM, maxN), x0, lb,ub,options);
catch ME
    x = [NaN, NaN];
    exitFlag = 0;
end

if exitflag == 1
    internalFound = 1;
    q = x(1);
    p = x(2);
    A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN);
    %disp("Equilibrium at q = " + q + " and p = " + p)
    qEquil = [qEquil, q];
    pEquil = [pEquil, p];
    AEquil = [AEquil, A];
else
    %disp("No internal equilibrium")
end