% This function generates the plots for the social welfare and throughput 
% of the MIPQ in Section 6.1.
% By Bryce Hassett

clc;
clear;
close all;
rng(1);

fullData = readtable('MIPQ_parameter_sweep_FINAL.csv'); % to not accidentally overwrite the csv

% List of possible parameter values in the data
% rhoVals = [0.2 0.5 0.9 1 1.1 1.5 2 2.5];
% muVals = 1;
% gammaVals = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
% RVals = [5 10];
% CVals = 1;
% PVals = [0 2 5];

mu = 1;
C = 1;
simulationTime = 1000;
trials = 100;
plots = 0;

% Plotting equilibrium (q,p) for various gamma
lambdaTargets = [0.5, 0.9, 1.1, 1.5, 2, 2.5];
RTarget = 5;
PTargets = [0, 2, 5];

lims = [0,1]; % bounds of the plots

%%
% Plotting for various lambda (tile for each P)
figure; % social welfare
t = tiledlayout(1, length(PTargets), 'TileSpacing', 'Compact');
for j = 1:length(PTargets)
    nexttile;
    hold on;
    for i = 1:length(lambdaTargets)
        targetRows = (fullData.lambda == lambdaTargets(i)) & (fullData.R == RTarget) & (fullData.P == PTargets(j));
        filteredData = fullData(targetRows, :);
        welNeg = filteredData.welfare - filteredData.welfareLower;
        welPos = filteredData.welfareUpper - filteredData.welfare;
        errorbar(filteredData.gamma, filteredData.welfare, welNeg, welPos, 'o-', 'LineWidth', 2);
        xlim(lims);
    end
    title_str = sprintf('P = %d', PTargets(j));
    title(title_str, "FontSize", 20);
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Average social welfare', "FontSize", 20, 'Interpreter', 'latex');
legend("$\lambda$ = " + lambdaTargets(1), "$\lambda$ = " + lambdaTargets(2), "$\lambda$ = " + lambdaTargets(3), "$\lambda$ = " + lambdaTargets(4), "$\lambda$ = " + lambdaTargets(5), "$\lambda$ = " + lambdaTargets(6) + " ", 'Interpreter', 'latex', 'FontSize', 20, 'Location', 'eastoutside');
title_str = sprintf('Effect of load on social welfare (R = %d)', RTarget);
title(t, title_str, "FontSize", 25);


figure; % throughput
t = tiledlayout(1, length(PTargets), 'TileSpacing', 'Compact');
for j = 1:length(PTargets)
    nexttile;
    hold on;
    for i = 1:length(lambdaTargets)
        targetRows = (fullData.lambda == lambdaTargets(i)) & (fullData.R == RTarget) & (fullData.P == PTargets(j));
        filteredData = fullData(targetRows, :);
        idleNeg = filteredData.idleProb - filteredData.idleProbLower;
        idlePos = filteredData.idleProbUpper - filteredData.idleProb;
        errorbar(filteredData.gamma, filteredData.idleProb, idleNeg, idlePos, 'o-', 'LineWidth', 2);
        xlim(lims);
    end
    title_str = sprintf('P = %d', PTargets(j));
    title(title_str, "FontSize", 20);
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Proportion of idle time', "FontSize", 20, 'Interpreter', 'latex');
legend("$\lambda$ = " + lambdaTargets(1), "$\lambda$ = " + lambdaTargets(2), "$\lambda$ = " + lambdaTargets(3), "$\lambda$ = " + lambdaTargets(4), "$\lambda$ = " + lambdaTargets(5), "$\lambda$ = " + lambdaTargets(6) + " ", 'Interpreter', 'latex', 'FontSize', 20, 'Location', 'eastoutside');
title_str = sprintf('Effect of load on proportion of idle time (R = %d)', RTarget);
title(t, title_str, "FontSize", 25);




% Plotting for various P (tile for each lambda)
figure; % social welfare
t = tiledlayout(2, 3, 'TileSpacing', 'Compact');
for j = 1:length(lambdaTargets)
    nexttile;
    hold on;
    for i = 1:length(PTargets)
        targetRows = (fullData.lambda == lambdaTargets(j)) & (fullData.R == RTarget) & (fullData.P == PTargets(i));
        filteredData = fullData(targetRows, :);
        welNeg = filteredData.welfare - filteredData.welfareLower;
        welPos = filteredData.welfareUpper - filteredData.welfare;
        errorbar(filteredData.gamma, filteredData.welfare, welNeg, welPos, 'o-', 'LineWidth', 2);
        xlim(lims);
    end
    title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(j));
    title(title_str, "FontSize", 20, 'interpreter', 'latex');
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Average social welfare', "FontSize", 20, 'Interpreter', 'latex');
legend("P = " + PTargets(1), "P = " + PTargets(2), "P = " + PTargets(3) + " ", 'FontSize', 20, 'Location', 'northeastoutside');
title_str = sprintf('Effect of priority fee on social welfare (R = %d)', RTarget);
title(t, title_str, "FontSize", 25);


figure; % throughput
t = tiledlayout(2, 3, 'TileSpacing', 'Compact');
for j = 1:length(lambdaTargets)
    nexttile;
    hold on;
    for i = 1:length(PTargets)
        targetRows = (fullData.lambda == lambdaTargets(j)) & (fullData.R == RTarget) & (fullData.P == PTargets(i));
        filteredData = fullData(targetRows, :);
        idleNeg = filteredData.idleProb - filteredData.idleProbLower;
        idlePos = filteredData.idleProbUpper - filteredData.idleProb;
        errorbar(filteredData.gamma, filteredData.idleProb, idleNeg, idlePos, 'o-', 'LineWidth', 2);
        xlim(lims);
    end
    title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(j));
    title(title_str, "FontSize", 20, 'interpreter', 'latex');
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Proportion of idle time', "FontSize", 20, 'Interpreter', 'latex');
legend("P = " + PTargets(1), "P = " + PTargets(2), "P = " + PTargets(3) + " ", 'FontSize', 20, 'Location', 'northeastoutside');
title_str = sprintf('Effect of priority fee on proportion of idle time (R = %d)', RTarget);
title(t, title_str, "FontSize", 25);