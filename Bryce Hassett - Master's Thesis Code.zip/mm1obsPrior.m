% This function simulates the fully observable priority queue, from 
% Section 4.2, for a specified parameter set, and outputs a sample path and 
% the resulting performance measures (for example, Figures 4.12 to 4.15).
% By Bryce Hassett

function [means, ciLower, ciUpper] = mm1obsPrior(lambda, mu, R, C, P, m, n, simulationTime, trials, plot)

obsPriorResults = [];

for j = 1:trials
    % Initialization
    currentTime = 0;
    serverFlag = 0; % 0 if server is idle, 1 if server is busy
    priorCustomersInQueue = 0; % Number of priority customers in the queue (excluding one in service)
    totalPriors = 0; % Total number of priority customers who visited the queue
    normCustomersInQueue = 0; % Number of ordinary customers in the queue (excluding one in service)
    totalNorms = 0; % Total number of normal customers who visited the queue
    timeEvents = 0; % Times when either an arrival or departure occurs
    stateEvents = 0; % Number of customers in system when an event occurs
    idleTime = 0; % Keep track of idle time
    arrivals = 0; % Number of customers who arrive at the queue
    arrivalTimes = [];
    normTimes = 0; % All times when ordinary customers either arrive or leave
    priorTimes = 0; % All times when priority customers either arrive or leave
    normState = 0; % Number of ordinary customers when an event occurs
    priorState = 0; % Number of priority customers when an event occurs
    departureTimes = [];
    priorLabels = []; % Keep track of which customers are ordinary (1) and which are priority (0)
    priorFlag = 1; % Current customer event (either arrival or departure), 1 if ordinary, 0 if priority
    balks = 0; % Number of customers who choose to not join the queue

    % Simulation Loop
    while currentTime < simulationTime
        % Generate next arrival and service times (Exponential Distribution)
        arrivalInterval = exprnd(1/lambda);
        serviceDuration = exprnd(1/mu);
        if serverFlag == 0
            nextEvent = arrivalInterval;
        else
            if arrivalInterval < serviceDuration
                nextEvent = arrivalInterval;
            else
                nextEvent = serviceDuration;
            end
        end
        if currentTime + nextEvent > simulationTime % Exit the loop if the next arrival/service event exceeds simulation time
            break;
        end

        % If system is empty, next event must be an arrival (regular customer)
        if serverFlag == 0
            idleTime = idleTime + arrivalInterval;
            currentTime = currentTime + arrivalInterval;
            serverFlag = 1; % now the server is occupied
            arrivals = arrivals + 1;
            arrivalTimes = [arrivalTimes, currentTime];
            priorFlag = 1;
            priorLabels = [priorLabels, 1]; % Index with an ordinary customer
        else
            % Compare next arrival and next service completion (this works
            % because of the memoryless property of exponentials)
            if arrivalInterval < serviceDuration % Arrival happens first
                currentTime = currentTime + arrivalInterval;

                if normCustomersInQueue < m % the next arrival is an ordinary customer
                    priorFlag = 1;
                    arrivals = arrivals + 1;
                    normCustomersInQueue = normCustomersInQueue + 1;
                    arrivalTimes = [arrivalTimes, currentTime];
                    priorLabels = [priorLabels, 1]; % Index with an ordinary customer

                elseif normCustomersInQueue == m && priorCustomersInQueue < n % the next arrival is a priority customer, so insert it in front of all ordinary customers in the queue (excluding server)
                    % For non-preemptive priority queue
                    priorFlag = 0;
                    arrivals = arrivals + 1;
                    priorCustomersInQueue = priorCustomersInQueue + 1;
                    if arrivals == length(arrivalTimes) + normCustomersInQueue + 1 % new priority customer is at the end of the line, which is empty (rare case, when there are no ordinary customers)
                        arrivalTimes = [arrivalTimes(1:arrivals-normCustomersInQueue-1), currentTime];
                        priorLabels = [priorLabels(1:arrivals-normCustomersInQueue-1), 0];
                    else
                        arrivalTimes = [arrivalTimes(1:arrivals-normCustomersInQueue-1), currentTime, arrivalTimes(arrivals-normCustomersInQueue:end)];
                        priorLabels = [priorLabels(1:arrivals-normCustomersInQueue-1), 0, priorLabels(arrivals-normCustomersInQueue:end)]; % Index with a priority customer
                    end
                else % queue is too long, so the customer balks
                    balks = balks + 1;
                end

            else
                % Service completion happens first
                currentTime = currentTime + serviceDuration;
                if normCustomersInQueue + priorCustomersInQueue == 0
                    serverFlag = 0; % server is idle again
                end

                
                if priorLabels(length(departureTimes)+1) == 1 % ordinary customer is served
                    priorFlag = 1;
                    totalNorms = totalNorms + 1;
                else % priority customer leaves
                    priorFlag = 0;
                    totalPriors = totalPriors + 1;
                end

                if serverFlag == 1
                    
                    if priorLabels(length(departureTimes)+2) == 1 % next customer to go into service is ordinary
                        normCustomersInQueue = max(0, normCustomersInQueue - 1);
                    else
                        priorCustomersInQueue = max(0, priorCustomersInQueue - 1);
                    end
                end

                departureTimes = [departureTimes, currentTime];
            end
        end

        % Record events for plotting
        timeEvents = [timeEvents, currentTime];
        stateEvents = [stateEvents, serverFlag + normCustomersInQueue + priorCustomersInQueue];

        if priorFlag == 1 % ordinary customer either arrives or leaves
            normTimes = [normTimes, currentTime];
            normState = [normState, normCustomersInQueue];
        else
            priorTimes = [priorTimes, currentTime];
            priorState = [priorState, priorCustomersInQueue];
        end
    end

    % for debugging
    timeEvents;
    stateEvents;
    arrivalTimes;
    departureTimes;
    priorLabels;

    % Calculating the average queue length (area under plot)
    totalTime = 0;
    i = 1;
    while i < length(stateEvents)
        totalTime = totalTime + (stateEvents(i) * (timeEvents(i+1)-timeEvents(i)));
        i = i+1;
    end
    averageLength = totalTime / simulationTime;

    % Calculating the average queue length (area under plot) for ordinary and priority queues
    totalNormTime = 0;
    i = 1;
    while i < length(normState)
        totalNormTime = totalNormTime + (normState(i) * (normTimes(i+1)-normTimes(i)));
        i = i+1;
    end
    averageNormLength = totalNormTime / simulationTime;

    totalPriorTime = 0;
    i = 1;
    while i < length(priorState)
        totalPriorTime = totalPriorTime + (priorState(i) * (priorTimes(i+1)-priorTimes(i)));
        i = i+1;
    end
    averagePriorLength = totalPriorTime / simulationTime;


    % Calculating the average (sojourn) time for a customer in the system
    arrivalTimesFixed = arrivalTimes(1:length(departureTimes)); % Match the arrivals with departures, to consider only customers who finish service
    customerWait = departureTimes - arrivalTimesFixed; % Each individual customer's time in system
    averageCustomerTime = sum(customerWait) / length(arrivalTimesFixed);

    % Calculating the average sojourn time for normal and priority customers separately
    customerLabelsFixed = priorLabels(1:length(departureTimes));
    normWait = (departureTimes - arrivalTimesFixed) .* customerLabelsFixed;
    priorWait = (departureTimes - arrivalTimesFixed) .* (1-customerLabelsFixed);
    averagePriorTime = sum(priorWait) / totalPriors;
    averageNormTime = sum(normWait) / totalNorms;

    % Calculating the proportion of time spent idle
    propIdle = idleTime / simulationTime;

    % Calculating the proportion of customers who actually join the system,
    % instead of balking
    propJoin = arrivals / (arrivals + balks);

    % Calculating the proportion of customers who purchased priority, out of
    % those who joined the queue
    propPrior = totalPriors / (totalNorms + totalPriors);

    % Calculating the social welfare (sum of customer utilities)
    welfare = (R*length(departureTimes) - P*totalPriors - C*sum(customerWait))/simulationTime;

    % Plotting the sample path
    if plot == 1 && j == 1
        figure;
        hold on;
        stairs(timeEvents, stateEvents, 'LineWidth', 1.5); % total number of customers
        stairs(priorTimes, priorState, 'LineWidth', 1.5); % number of priority customers
        stairs(normTimes, normState, 'LineWidth', 1.5); % number of ordinary customers
        
        title_str = sprintf('Observable Priority Queue (lambda = %.1f, mu = %.1f, R = %.1f, C = %.1f, P = %.1f)', lambda, mu, R, C, P);
        title(title_str, "FontSize", 20);
        xlabel('Time (minutes)', "FontSize", 20);
        ylabel('Number of Customers in System', "FontSize", 20);
        legend('Total', 'Priority', 'Ordinary');
        grid on;
    end

    trialResults = [averageLength, averageNormLength, averagePriorLength, averageCustomerTime, averageNormTime, averagePriorTime, propIdle, propJoin, propPrior, welfare];
    obsPriorResults(end+1, :) = trialResults;
end
obsPriorResults; % all results
[~, ~, ci] = ttest(obsPriorResults);
means = mean(obsPriorResults, 1);
ciLower = ci(1:2:end);
ciUpper = ci(2:2:end);
end