% This function runs simulations of the fully unobservable FCFS queue 
% over various joining probabilities, q, and generates the plots for 
% social welfare and throughput in Section 3.1.2 (Figures 3.4 and 3.5).
% By Bryce Hassett

clc;
clear;
close all;
format short

rng(1);
trials = 10; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.5;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
simulationTime = 1000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 6; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
probs = 0:0.05:1; % Possible joining probabilities

meanIdle = [];
lowerIdle = [];
upperIdle = [];
meanWelfare = [];
lowerWelfare = [];
upperWelfare = [];

for i = 1:length(probs)
    q = probs(i);
    [unobsAvg, unobsCILow, unobsCIHigh] = mm1unobservable(lambda, mu, R, C, q, simulationTime, trials, plots);

    meanIdle = [meanIdle, unobsAvg(3)];
    lowerIdle = [lowerIdle, unobsCILow(3)];
    upperIdle = [upperIdle, unobsCIHigh(3)];

    meanWelfare = [meanWelfare, unobsAvg(5)];
    lowerWelfare = [lowerWelfare, unobsCILow(5)];
    upperWelfare = [upperWelfare, unobsCIHigh(5)];

    disp(['Finished ', num2str(i), ' of ', num2str(length(probs))])
end

% Average idle time
idleNeg = meanIdle - lowerIdle;
idlePos = upperIdle - meanIdle;
figure;
hold on;
errorbar(probs, meanIdle, idleNeg, idlePos, '-o', 'LineWidth', 2)
title_str = sprintf('Average Proportion of Idle Time (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('q', "FontSize", 20);
ylabel('Average idle time', "FontSize", 20);
grid on;

% Average welfare
welfareNeg = meanWelfare - lowerWelfare;
welfarePos = upperWelfare - meanWelfare;
figure;
hold on;
errorbar(probs, meanWelfare, welfareNeg, welfarePos, '-o', 'LineWidth', 2)
title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('q', "FontSize", 20);
ylabel('Social Welfare', "FontSize", 20);
grid on;

% Average welfare between q = 0 and q = 0.6
probsShort = probs(1:13);
meanWelfareShort = meanWelfare(1:13);
lowerWelfareShort = lowerWelfare(1:13);
upperWelfareShort = upperWelfare(1:13);

welfareNegShort = meanWelfareShort - lowerWelfareShort;
welfarePosShort = upperWelfareShort - meanWelfareShort;
figure;
hold on;
errorbar(probsShort, meanWelfareShort, welfareNegShort, welfarePosShort, '-o', 'LineWidth', 2)
title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('q', "FontSize", 20);
ylabel('Social Welfare', "FontSize", 20);
grid on;