% This function performs a parameter sweep for the unobservable FCFS queue 
% over various values of parameters, and saves the results to a csv file

% The core foundation of the code was provided by ChatGPT (including the 
% saving mechanism), although it was heavily modified by Bryce Hassett

function results = unobsFCFSParameterSweep(rhoVals, muVals, gammaVals, ...
                                      RVals, CVals, PVals, ...
                                      trials, runs, maxTime, simulationTime, plots, ...
                                      outputFile, saveEvery)

% Parameter sweep for the fully unobservable FCFS queue with incremental saving and automatic resume.
%
% If outputFile already exists, completed parameter combinations are
% loaded and skipped automatically.
%
% saveEvery = number of newly completed combinations between saves.
% Use saveEvery = 1 for maximum protection against losing results.

%% Total number of combinations
gammaVals = NaN; %  not a mixed information queue, so gamma does not matter
PVals = NaN; % not a priority queue, so P does not matter

numCombinations = length(rhoVals) * ...
                  length(muVals) * ...
                  length(gammaVals) * ...
                  length(RVals) * ...
                  length(CVals) * ...
                  length(PVals);

fprintf('Total parameter combinations: %d\n', numCombinations);

%% Preallocate results

combinationIDResults = (1:numCombinations)';

lambdaResults = NaN(numCombinations,1);
muResults = NaN(numCombinations,1);
rhoResults = NaN(numCombinations,1);
gammaResults = NaN(numCombinations,1);
RResults = NaN(numCombinations,1);
CResults = NaN(numCombinations,1);
PResults = NaN(numCombinations,1);

% means
idleProbResults = NaN(numCombinations,1);
welfareResults = NaN(numCombinations,1);

% CI Lower
idleProbResultsLower = NaN(numCombinations,1);
welfareResultsLower = NaN(numCombinations,1);

% CI Upper
idleProbResultsUpper = NaN(numCombinations,1);
welfareResultsUpper = NaN(numCombinations,1);

%% Check whether previous results exist

completed = false(numCombinations, 1);

if isfile(outputFile)

    fprintf('Existing results file found: %s\n', outputFile);

    oldResults = readtable(outputFile);

    if ismember('combinationID', oldResults.Properties.VariableNames)

        % -------------------------------------------------------------
        % 1. Remove invalid combination IDs
        % -------------------------------------------------------------
        validRows = ~isnan(oldResults.combinationID) & ...
                    oldResults.combinationID >= 1 & ...
                    oldResults.combinationID <= numCombinations;

        oldResults = oldResults(validRows, :);

        % -------------------------------------------------------------
        % 2. Remove duplicate combination IDs
        %    Keep the LAST occurrence
        % -------------------------------------------------------------
        [~, uniqueIdx] = unique(oldResults.combinationID, 'last');

        uniqueIdx = sort(uniqueIdx);

        oldResults = oldResults(uniqueIdx, :);

        % -------------------------------------------------------------
        % 3. Load old results
        % -------------------------------------------------------------
        for k = 1:height(oldResults)

            id = oldResults.combinationID(k);

            combinationIDResults(id) = id;

            lambdaResults(id) = oldResults.lambda(k);
            muResults(id) = oldResults.mu(k);
            rhoResults(id) = oldResults.rho(k);
            gammaResults(id) = oldResults.gamma(k);
            RResults(id) = oldResults.R(k);
            CResults(id) = oldResults.C(k);
            PResults(id) = oldResults.P(k);

            idleProbResults(id) = oldResults.idleProb(k);
            welfareResults(id) = oldResults.welfare(k);

            % Lower CI
            idleProbResultsLower(id) = oldResults.idleProbLower(k);
            welfareResultsLower(id) = oldResults.welfareLower(k);

            % Upper CI
            idleProbResultsUpper(id) = oldResults.idleProbUpper(k);
            welfareResultsUpper(id) = oldResults.welfareUpper(k);

            % Mark this combination as already completed
            completed(id) = true;

        end

        fprintf('%d existing combinations loaded.\n', sum(completed));

    else

        warning('Existing CSV does not contain a combinationID column. Starting from scratch.');

    end

else

    fprintf('No existing results file found. Starting from scratch.\n');

end

%% Main parameter sweep

counter = 0;

for rho = rhoVals

    for mu = muVals

        % lambda is determined from rho and mu
        lambda = rho * mu;

        for gamma = gammaVals

            for R = RVals

                for C = CVals

                    for P = PVals

                        %% Determine combination ID

                        counter = counter + 1;

                        combinationID = counter;

                        %% Skip if already completed

                        if completed(combinationID)

                            fprintf('\nSkipping combination %d / %d ', ...
                                combinationID, numCombinations);
                            fprintf('(already completed)\n');

                            continue;

                        end

                        %% Display current parameters

                        fprintf('\n========================================\n');
                        fprintf('Combination %d / %d (Unobservable FCFS)\n', ...
                            combinationID, numCombinations);
                        fprintf('rho       = %.4f\n', rho);
                        fprintf('lambda    = %.4f\n', lambda);
                        fprintf('mu        = %.4f\n', mu);
                        fprintf('gamma     = %.4f\n', gamma);
                        fprintf('R         = %.4f\n', R);
                        fprintf('C         = %.4f\n', C);
                        fprintf('P         = %.4f\n', P);
                        fprintf('========================================\n');

                        %% Store parameter values

                        combinationIDResults(combinationID) = combinationID;

                        lambdaResults(combinationID) = lambda;
                        muResults(combinationID) = mu;
                        rhoResults(combinationID) = rho;
                        gammaResults(combinationID) = gamma;
                        RResults(combinationID) = R;
                        CResults(combinationID) = C;
                        PResults(combinationID) = P;

                        %% Run equilibrium calculation

                        q = unobsEquil(lambda, mu, R, C); % equilibrium joining probability
                        [unobsAvg, unobsCILow, unobsCIHigh] = mm1unobservable(lambda, mu, R, C, q, simulationTime, trials, plots);
                        results = [unobsAvg; unobsCILow; unobsCIHigh];

                        %% Store equilibrium results
                        % Means
                        idleProbResults(combinationID) = ...
                            results(1,3);

                        welfareResults(combinationID) = ...
                            results(1,5);

                        % CI Lower
                        idleProbResultsLower(combinationID) = ...
                            results(2,3);

                        welfareResultsLower(combinationID) = ...
                            results(2,5);

                        % CI Upper
                        idleProbResultsUpper(combinationID) = ...
                            results(3,3);

                        welfareResultsUpper(combinationID) = ...
                            results(3,5);

                        %% Mark combination as completed

                        completed(combinationID) = true;

                        %% Save progress

                        newlyCompleted = sum(completed);

                        if mod(newlyCompleted, saveEvery) == 0 || ...
                           combinationID == numCombinations

                            resultsFinal = table( ...
                                combinationIDResults(completed), ...
                                lambdaResults(completed), ...
                                muResults(completed), ...
                                rhoResults(completed), ...
                                gammaResults(completed), ...
                                RResults(completed), ...
                                CResults(completed), ...
                                PResults(completed), ...
                                idleProbResults(completed), ...
                                welfareResults(completed), ...
                                idleProbResultsLower(completed), ...
                                welfareResultsLower(completed), ...
                                idleProbResultsUpper(completed), ...
                                welfareResultsUpper(completed), ...
                                'VariableNames', { ...
                                'combinationID', ...
                                'lambda', ...
                                'mu', ...
                                'rho', ...
                                'gamma', ...
                                'R', ...
                                'C', ...
                                'P', ...
                                'idleProb', ...
                                'welfare', ...
                                'idleProbLower', ...
                                'welfareLower', ...
                                'idleProbUpper', ...
                                'welfareUpper'
                                });

                            % Sort by combination ID
                            resultsFinal = sortrows(resultsFinal, ...
                                               'combinationID');

                            writetable(resultsFinal, outputFile);

                            fprintf('\n*** Progress saved: %d / %d ***\n', ...
                                    newlyCompleted, numCombinations);

                        end

                    end
                end
            end
        end
    end
end

%% Final result

resultsFinal = table( ...
    combinationIDResults(completed), ...
    lambdaResults(completed), ...
    muResults(completed), ...
    rhoResults(completed), ...
    gammaResults(completed), ...
    RResults(completed), ...
    CResults(completed), ...
    PResults(completed), ...
    idleProbResults(completed), ...
    welfareResults(completed), ...
    idleProbResultsLower(completed), ...
    welfareResultsLower(completed), ...
    idleProbResultsUpper(completed), ...
    welfareResultsUpper(completed), ...
    'VariableNames', { ...
    'combinationID', ...
    'lambda', ...
    'mu', ...
    'rho', ...
    'gamma', ...
    'R', ...
    'C', ...
    'P', ...
    'idleProb', ...
    'welfare', ...
    'idleProbLower', ...
    'welfareLower', ...
    'idleProbUpper', ...
    'welfareUpper'
    });

resultsFinal = sortrows(resultsFinal, 'combinationID');

fprintf('\n========================================\n');
fprintf('Parameter sweep complete.\n');
fprintf('Completed: %d / %d combinations\n', ...
        sum(completed), numCombinations);
fprintf('========================================\n');

end