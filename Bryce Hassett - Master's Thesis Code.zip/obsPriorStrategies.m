% This function generates the heatmaps for the social welfare and 
% throughput of the system over various off-equilibrium strategies 
% in Section 4.2.2 (Figures 4.19 and 4.20).
% By Bryce Hassett

clc;
clear;
close all;
format short

rng(1);
trials = 10; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.8;  % Arrival rate (customers/minute)
mu = 2;      % Service rate (customers/minute)
simulationTime = 1000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 10; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
P = 5; % Priority fee
thresh1 = 0:20; % Possible thresholds m
thresh2 = 0:20; % Possible thresholds n

meanIdle = [];
meanWelfare = [];

count = 0;
for i = 1:length(thresh1)
    m = thresh1(i);
    for j = 1:length(thresh2)   
        n = thresh2(j);
        [obsPriorAvg, obsPriorCILow, obsPriorCIHigh] = mm1obsPrior(lambda, mu, R, C, P, m, n, simulationTime, trials, plots);

        meanIdle(i,j) = obsPriorAvg(7);
        meanWelfare(i,j) = obsPriorAvg(10);
        count = count + 1;

        disp(['Finished ', num2str(count), ' of ', num2str(length(thresh1)*length(thresh2))])
    end
end

% Average welfare
figure;
h1 = heatmap(thresh2, thresh1, meanWelfare);

sh = struct(h1);
sh.Axes.XLabel.FontSize = 16;
sh.Axes.YLabel.FontSize = 16;
sh.Axes.Title.FontSize = 16;

title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
h1.Title = title_str;
h1.XLabel = 'n';
h1.YLabel = 'm';
grid on;

% Average proportion of idle time
figure;
h2 = heatmap(thresh2, thresh1, meanIdle);

sh = struct(h2);
sh.Axes.XLabel.FontSize = 16;
sh.Axes.YLabel.FontSize = 16;
sh.Axes.Title.FontSize = 16;

title_str = sprintf('Average Proportion of Idle Time (lambda = %.1f, R = %.1f)', lambda, R);
h2.Title = title_str;
h2.XLabel = 'n';
h2.YLabel = 'm';
grid on;