% This function provides a comparison between the observable FCFS and 
% priority queues, over various priority fees (Figure 4.18). It also 
% outputs a plot for the probability of purchasing priority over 
% various priority fees (Figure 4.17).
% By Bryce Hassett

clc;
clear;
close all;
format short

rng(1);
trials = 100; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.8;  % Arrival rate (customers/minute)
mu = 2;      % Service rate (customers/minute)
simulationTime = 10000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 10; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
premiums = 0:1:R; % Priority fees

meanWait = [];
lowerWait = [];
upperWait = [];
meanIdle = [];
lowerIdle = [];
upperIdle = [];
meanJoin = [];
lowerJoin = [];
upperJoin = [];
meanPrior = [];
lowerPrior = [];
upperPrior = [];
meanWelfare = [];
lowerWelfare = [];
upperWelfare = [];

% M/M/1 Observable Queue (with balking)
N = floor(R*mu/C);
[obsAvg, obsCILow, obsCIHigh] = mm1observable(lambda, mu, R, C, N, simulationTime, trials, plots);

FCFSmeanWait = obsAvg(2)*ones(1, length(premiums));
FCFSlowerWait = obsCILow(2)*ones(1, length(premiums));
FCFSupperWait = obsCIHigh(2)*ones(1, length(premiums));

FCFSmeanIdle = obsAvg(3)*ones(1, length(premiums));
FCFSlowerIdle = obsCILow(3)*ones(1, length(premiums));
FCFSupperIdle = obsCIHigh(3)*ones(1, length(premiums));

FCFSmeanJoin = obsAvg(4)*ones(1, length(premiums));
FCFSlowerJoin = obsCILow(4)*ones(1, length(premiums));
FCFSupperJoin = obsCIHigh(4)*ones(1, length(premiums));

FCFSmeanWelfare = obsAvg(5)*ones(1, length(premiums));
FCFSlowerWelfare = obsCILow(5)*ones(1, length(premiums));
FCFSupperWelfare = obsCIHigh(5)*ones(1, length(premiums));

% M/M/1 Observable Priority Queue (with balking)
disp("Observable Priority Queue")
for i = 1:length(premiums)
    P = premiums(i);
    [m, n] = obsPriorEquil(lambda, mu, R, C, P);
    [obsPriorAvg, obsPriorCILow, obsPriorCIHigh] = mm1obsPrior(lambda, mu, R, C, P, m, n, simulationTime, trials, plots);
    
    meanWait = [meanWait, obsPriorAvg(4)];
    lowerWait = [lowerWait, obsPriorCILow(4)];
    upperWait = [upperWait, obsPriorCIHigh(4)];

    meanIdle = [meanIdle, obsPriorAvg(7)];
    lowerIdle = [lowerIdle, obsPriorCILow(7)];
    upperIdle = [upperIdle, obsPriorCIHigh(7)];

    meanJoin = [meanJoin, obsPriorAvg(8)];
    lowerJoin = [lowerJoin, obsPriorCILow(8)];
    upperJoin = [upperJoin, obsPriorCIHigh(8)];

    meanPrior = [meanPrior, obsPriorAvg(9)];
    lowerPrior = [lowerPrior, obsPriorCILow(9)];
    upperPrior = [upperPrior, obsPriorCIHigh(9)];

    meanWelfare = [meanWelfare, obsPriorAvg(10)];
    lowerWelfare = [lowerWelfare, obsPriorCILow(10)];
    upperWelfare = [upperWelfare, obsPriorCIHigh(10)];

    disp(['Finished PQ ', num2str(i), ' of ', num2str(length(premiums))])
end

% Average customer waiting time
waitNeg = meanWait - lowerWait;
waitPos = upperWait - meanWait;
figure;
hold on;
errorbar(premiums, meanWait, waitNeg, waitPos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanWait, '-o', 'LineWidth', 2)
title_str = sprintf('Average Waiting Time (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Average waiting time (minutes)', "FontSize", 20);
legend('Priority Queue', 'FCFS Queue');
grid on;

% Average idle time
idleNeg = meanIdle - lowerIdle;
idlePos = upperIdle - meanIdle;
figure;
hold on;
errorbar(premiums, meanIdle, idleNeg, idlePos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanIdle, '-o', 'LineWidth', 2)
title_str = sprintf('Average Proportion of Idle Time (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Average idle time', "FontSize", 20);
legend('Priority Queue', 'FCFS Queue');
grid on;

% Average welfare
welfareNeg = meanWelfare - lowerWelfare;
welfarePos = upperWelfare - meanWelfare;
figure;
hold on;
errorbar(premiums, meanWelfare, welfareNeg, welfarePos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanWelfare, '-o', 'LineWidth', 2)
title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Social Welfare', "FontSize", 20);
legend('Priority Queue', 'FCFS Queue');
grid on;

% Joining probability
figure;
hold on;
plot(premiums, meanJoin, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanJoin, '-o', 'LineWidth', 2)
title_str = sprintf('Probability of joining (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Probability', "FontSize", 20);
legend('Priority Queue', 'FCFS Queue');
grid on;

% Priority probability
figure;
plot(premiums, meanPrior, '-o', 'LineWidth', 2)
title_str = sprintf('Proportion of priority customers (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Proportion', "FontSize", 20);
grid on;

figure;
t = tiledlayout(2, 2);

nexttile;
hold on;
errorbar(premiums, meanWait, waitNeg, waitPos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanWait, '-o', 'LineWidth', 2)
title_str = sprintf('(a) Average Waiting Time');
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 15);
legend('Priority Queue', 'FCFS Queue');

nexttile;
hold on;
errorbar(premiums, meanIdle, idleNeg, idlePos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanIdle, '-o', 'LineWidth', 2)
title_str = sprintf('(b) Average Proportion of Idle Time');
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 15);
legend('Priority Queue', 'FCFS Queue');

nexttile;
hold on;
errorbar(premiums, meanWelfare, welfareNeg, welfarePos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanWelfare, '-o', 'LineWidth', 2)
title_str = sprintf('(c) Social Welfare');
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 15);
legend('Priority Queue', 'FCFS Queue');

nexttile;
hold on;
plot(premiums, meanJoin, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanJoin, '-o', 'LineWidth', 2)
title_str = sprintf('(d) Probability of joining');
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 15);
legend('Priority Queue', 'FCFS Queue');