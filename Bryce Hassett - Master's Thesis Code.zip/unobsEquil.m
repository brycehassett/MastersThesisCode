% This function computes the equilibrium joining probability, q, for 
% customers in the fully unobservable FCFS queue, from Section 3.1.1.
% By Bryce Hassett

function q = unobsEquil(lambda, mu, R, C)

if lambda > mu - C/R
    q = (1/lambda) * (mu - C/R);
elseif mu - C/R <= 0
    q = 0;
else
    q = 1;
end