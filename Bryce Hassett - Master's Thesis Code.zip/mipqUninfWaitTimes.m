% This function simulates the expected sojourn times for ordinary and 
% priority customers for every possible state. Combining this with the 
% stationary distribution produced by mipqUninfStatDist.m gives the 
% expected utilities for an arriving uninformed customer, if they choose 
% to purchase priority or not.
% By Bryce Hassett

function [Wo, Wp] = mipqUninfWaitTimes(lambda, mu, gamma, R, P, C, q, p, A, maxTime, trials, pi_Matrix)
[maxM, maxN] = size(A);
maxM = maxM - 1; % index shift
maxN = maxN - 1;

Wo = zeros(maxM+1, maxN+1); % expected sojourn time for ordinary customers, for every state
Wp = zeros(maxM+1, maxN+1); % expected sojourn time for priority customers, for every state

% the state we are testing
initM = 0;
initN = 0;

while initN <= maxN
    while initM < maxM
        % for speed
        if norm(pi_Matrix(initM+1, initN+1)) <= 0.0001 % we don't need this value since it will be multiplied by zero
            Wp(initM+1, initN+1) = (initN+2)/mu;
            initM = initM + 1; % ready to try the next state
            continue
        end
        
        waits = []; % waiting time for each trial, for the given state
        for j = 1:trials
            % Initialization
            currentTime = 0;
            serverFlag = 1; % 0 if server is idle, 1 if server is busy
            position = initM + initN + 1; % Initial position of tagged ordinary customer in queue (excluding server)
            
            % M and N are the numbers of ordinary and priority customers in the queue
            M = initM + 1; % tagged customer joins as ordinary
            N = initN;
            
            timeEvents = 0; % Times when either an arrival or departure occurs
            stateEvents = 0; % Number of customers in system when an event occurs
            arrivals = 0; % Number of customers who arrive at the queue
            departureTimes = [];

            % Simulation Loop
            while currentTime < maxTime

                % Generate next arrival and service times (Exponential Distribution)
                arrivalInterval = exprnd(1/lambda);
                serviceDuration = exprnd(1/mu);
                if arrivalInterval < serviceDuration
                    nextEvent = arrivalInterval;
                else
                    nextEvent = serviceDuration;
                end
                if currentTime + nextEvent > maxTime % Exit the loop if the time exceeds the maximum time
                    currentTime = maxTime;
                    break;
                end

                % Compare next arrival and next service completion (this works
                % because of the memoryless property of exponentials)
                if arrivalInterval < serviceDuration % Arrival happens first
                    currentTime = currentTime + arrivalInterval;

                    if rand() > gamma % uninformed customer arrives
                        if rand() < q % uninformed customer joins
                            arrivals = arrivals + 1;
                            if rand() > p && M < maxM % uninformed ORDINARY
                                M = M + 1;
                            elseif rand() <= p && N < maxN % uninformed PRIORITY
                                % For non-preemption priority queue
                                N = N + 1;
                                position = position + 1;
                            end
                        end
                    else % informed customer arrives
                        if A(M+1, N+1) == 2 && M < maxM % informed ORDINARY
                            arrivals = arrivals + 1;
                            M = M + 1;

                        elseif A(M+1, N+1) == 1 && N < maxN % informed PRIORITY
                            % For non-preemption priority queue
                            arrivals = arrivals + 1;
                            N = N + 1;
                            position = position + 1;
                        end
                    end

                else
                    % Service completion happens first
                    currentTime = currentTime + serviceDuration;
                    if position == 1
                        % tagged customer will be served now
                        bonusServiceDuration = exprnd(1/mu);
                        currentTime = currentTime + bonusServiceDuration; % the tagged customer being served
                        departureTimes = [departureTimes, currentTime];
                        break; % simulation done
                    end

                    position = position - 1;

                    if N == 0 % next customer to go into service is ordinary
                        M = max(0, M - 1);
                    else
                        N = max(0, N - 1);
                    end

                    departureTimes = [departureTimes, currentTime];
                end
            end


            % Calculating the average (sojourn) time for a customer in the system
            waits = [waits, currentTime];
        end

        Wo(initM+1, initN+1) = mean(waits);
        Wp(initM+1, initN+1) = (initN+2)/mu;

        initM = initM + 1; % ready to try the next state
    end
    Wp(end, initN+1) = (initN+2)/mu;
    initM = 0;
    initN = initN + 1;
end