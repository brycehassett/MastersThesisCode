% This function computes the equilibrium strategy matrix A for 
% informed customers of the MIPQ, given a particular (q, p).
% By Bryce Hassett

function A = mipqInfEquilFunc(lambda, mu, gamma, R, C, P, q, p, trials, maxTime, maxM, maxN)

rho = lambda/mu; % System load
vR = R*mu/C; % Service reward relative to average waiting cost for a service cycle
vP = P*mu/C; % Priority premium relative to average waiting cost for a service cycle
n = min(floor(vR - vP) - 1, maxN); % threshold between balking and joining with priority (needs to be less than maxN)

% State to test (row M, col N)
M = 0;
N = 0;

priorUtil = R - P - (N+2)*C/mu;

% Strategy matrix: entries are 0 if balk, 1 if priority, 2 if ordinary
A = zeros(maxM+1,maxN+1);
A(:, 1:n) = 1;

while N < maxN
    while M < maxM
        state = [M, N];
        expWait = mipqInfStateSim(lambda, mu, gamma, q, p, A, M, N, maxTime, trials);

        ordUtil = R - C*expWait;
        priorUtil = R - P - (N+2)*C/mu;
        if ordUtil < -0.1 && priorUtil < -0.1
            %disp("Balking is best")
            A(M+1, N+1) = 0;
            break; % if balking is best when M ordinary, it is best when >M ordinary

        elseif ordUtil > priorUtil
            %disp("Ordinary is best")
            A(M+1, N+1) = 2;

        elseif priorUtil > ordUtil
            %disp("Priority is best")
            A(M+1, N+1) = 1;
            break; % if priority is best when M ordinary, it is best when >M ordinary

        end
        M = M + 1; % Next try state (1, 0)
    end
    M = 0;
    N = N + 1;
end

% Loop and fix the strategy for incorrect states until a best response is reached
bestResponse = 0;
iters = 0;
while bestResponse == 0
    [A, bestResponse, wrongStates] = mipqBestResponse(lambda, mu, gamma, R, C, P, q, p, A, maxTime, trials, maxM, maxN);
    wrongStates;
    iters = iters + 1;
end

% debugging
A;
iters;
end