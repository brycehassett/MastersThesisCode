% This function plots the relationship between the joining probabilities 
% (for uninformed and informed customers) against the information level, 
% from Section 3.3.1 (Figures 3.10 and 3.12)
% By Bryce Hassett

clc
clear
close all

rng(1);
trials = 100; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.5;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
simulationTime = 10000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 6; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
gammas = 0:0.05:1; % Possible information levels

meanPropUninf = [];
meanPropInf = [];
lowerPropInf = [];
upperPropInf = [];

for i = 1:length(gammas)
    gamma = gammas(i);
    [N, q] = mixedEquil(lambda, mu, R, C, gamma);
    [mixedAvg, mixedCILow, mixedCIHigh] = mixedQueue(lambda, mu, R, C, gamma, q, N, simulationTime, trials, plots);

    if i < length(gammas)
        meanPropUninf = [meanPropUninf, mixedAvg(6)];
    end

    meanPropInf = [meanPropInf, mixedAvg(7)];
    lowerPropInf = [lowerPropInf, mixedCILow(7)];
    upperPropInf = [upperPropInf, mixedCIHigh(7)];

    disp(['Finished ', num2str(i), ' of ', num2str(length(gammas))])
end

% Average joining proportion for both streams of customers
propInfNeg = meanPropInf - lowerPropInf;
propInfPos = upperPropInf - meanPropInf;
figure;
hold on;
errorbar(gammas, meanPropInf, propInfNeg, propInfPos, '-o', 'LineWidth', 2)
plot(gammas(1:end-1), meanPropUninf, '-o', 'LineWidth', 2)
title_str = sprintf('Joining proportions ($\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$, $\\mathbf{R}$ $\\mathbf{=}$ $\\mathbf{%.1f}$)', lambda, R);
title(title_str, "FontSize", 20, 'Interpreter', 'latex');
ax = gca;
ax.XAxis.FontSize = 16;
ay = gca;
ay.YAxis.FontSize = 16;
xlabel('Information level', "FontSize", 20);
ylabel('Joining proportion', "FontSize", 20);
xlim([0 1])
ylim([0 1])
legend('Informed', 'Uninformed', 'FontSize', 20);
grid on;