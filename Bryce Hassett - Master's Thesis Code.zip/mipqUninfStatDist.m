% This function computes the stationary distribution of the MIPQ, 
% for a given (A, q, p).
% By Bryce Hassett

function pi = mipqUninfStatDist(lambda, mu, gamma, q, p, A, maxM, maxN)

lambdaI = gamma*lambda;
lambdaU = (1-gamma)*lambda;
N = 1 + (maxM+1)*(maxN+1);

Q = zeros(N,N);

idx = @(i,j) 2 + i*(maxN+1) + j;

% Idle -> (0,0)
Q(1,idx(0,0)) = q*lambdaU + lambdaI;

% (0,0) -> idle
Q(idx(0,0),1) = mu;

for i = 0:maxM
    for j = 0:maxN
        s = idx(i,j);

        % Effective arrival rates
        alpha = q*(1-p)*lambdaU + lambdaI*(A(i+1,j+1) == 2);
        beta = q*p*lambdaU + lambdaI*(A(i+1,j+1) == 1);

        % Ordinary arrival
        if i < maxM
            Q(s,idx(i+1,j)) = alpha;
        end

        % Priority arrival
        if j < maxN
            Q(s,idx(i,j+1)) = beta;
        end

        % Service completion
        if j > 0
            Q(s,idx(i,j-1)) = mu;
        elseif i > 0
            Q(s,idx(i-1,j)) = mu;
        end
    end
end

% Set diagonal entries
for s = 1:N
    Q(s,s) = -sum(Q(s,:));
end

% Stationary distribution
M = Q';

% Replace one redundant equation with normalization
M(1,:) = 1;
b = zeros(N,1);
b(1) = 1;

pi = M\b;
end