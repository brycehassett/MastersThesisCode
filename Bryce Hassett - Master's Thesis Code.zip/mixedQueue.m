% This function simulates the mixed information FCFS queue, from 
% Section 3.3, for a specified parameter set, and outputs a sample path and 
% the resulting performance measures (for example, Figure 3.9).
% By Bryce Hassett

function [means, ciLower, ciUpper] = mixedQueue(lambda, mu, R, C, gamma, q, n, simulationTime, trials, plot)
% Recall that gamma = proportion of informed customers, q = probability that an uninformed customer joins. 

mixedResults = [];

for j = 1:trials
    % Initialization
    currentTime = 0;
    customersInSystem = 0;
    informedInSystem = 0; % number of informed customers
    uninformedInSystem = 0; % number of uninformed customers
    timeEvents = 0; % Times when either an arrival or departure occurs
    stateEvents = 0; % Number of customers in system when an event occurs
    idleTime = 0; % Keep track of idle time
    arrivals = 0; % Number of customers who arrive at the queue
    arrivalTimes = [];
    departureTimes = [];
    balks = 0; % number of informed customers who choose not to join
    customerLabels = []; % Informed (1) vs Uninformed (0) customers who join the queue
    next = 0; % Label of the next arriving customer
    customersServed = 0; % Total number of customers who have been served

    % Simulation Loop
    while currentTime < simulationTime
        % Generate next arrival and service times (Exponential Distribution)
        arrivalInterval = exprnd(1/lambda);
        serviceDuration = exprnd(1/mu);

        if customersInSystem == 0
            nextEvent = arrivalInterval;
        else
            if arrivalInterval < serviceDuration
                nextEvent = arrivalInterval;
            else
                nextEvent = serviceDuration;
            end
        end
        if currentTime + nextEvent > simulationTime % Exit the loop if the next arrival/service event exceeds simulation time
            break;
        end

        if rand() < gamma
            next = 1; % informed
        else 
            next = 0; % uninformed
            if rand() < q
                joins = 1; % uninformed customer joins
            else
                joins = 0; % informed customer joins
            end
        end

        % If system is empty, next event must be an arrival
        if customersInSystem == 0 % no matter if the arrival is informed or uninformed, they will always join if the server is idle
            if next == 0 % uninformed arrives
                if joins == 0 % uninformed balks
                    continue
                else
                    idleTime = idleTime + arrivalInterval;
                    currentTime = currentTime + arrivalInterval;
                    customersInSystem = 1;
                    arrivals = arrivals + 1;
                    arrivalTimes = [arrivalTimes, currentTime];
                    customerLabels = [customerLabels, next];
                    uninformedInSystem = 1 - next;
                    informedInSystem = next;
                end
            else % informed arrives
                idleTime = idleTime + arrivalInterval;
                currentTime = currentTime + arrivalInterval;
                customersInSystem = 1;
                arrivals = arrivals + 1;
                arrivalTimes = [arrivalTimes, currentTime];
                customerLabels = [customerLabels, next];
                uninformedInSystem = 1 - next;
                informedInSystem = next;
            end
        else
            % Compare next arrival and next service completion (this works
            % because of the memoryless property of exponentials)
            if arrivalInterval < serviceDuration
                % Arrival happens first
                currentTime = currentTime + arrivalInterval;
                if next == 0 % this is an uninformed customer
                    if joins == 0
                        continue
                    else
                        customersInSystem = customersInSystem + 1;
                        uninformedInSystem = uninformedInSystem + 1;
                        arrivals = arrivals + 1;
                        arrivalTimes = [arrivalTimes, currentTime];
                        customerLabels = [customerLabels, next];
                    end
                else % this is an informed customer
                    if customersInSystem < n % The queue is short enough for the customer to join
                        customersInSystem = customersInSystem + 1;
                        informedInSystem = informedInSystem + 1;
                        arrivals = arrivals + 1;
                        arrivalTimes = [arrivalTimes, currentTime];
                        customerLabels = [customerLabels, next];
                    else
                        balks = balks + 1; % Otherwise, they balk
                    end
                end

            else
                % Service completion happens first
                currentTime = currentTime + serviceDuration;
                customersInSystem = customersInSystem - 1;
                departureTimes = [departureTimes, currentTime];
                customersServed = customersServed + 1;
                uninformedInSystem = uninformedInSystem - (1 - customerLabels(customersServed));
                informedInSystem = informedInSystem - customerLabels(customersServed);
            end
        end

        % Record events for plotting
        timeEvents = [timeEvents, currentTime];
        stateEvents = [stateEvents, customersInSystem];
    end

    % for debugging
    timeEvents;
    stateEvents;
    arrivalTimes;
    departureTimes;

    % Calculating the average queue length (area under plot)
    totalTime = 0;
    i = 1;
    while i < length(stateEvents)
        totalTime = totalTime + (stateEvents(i) * (timeEvents(i+1)-timeEvents(i)));
        i = i+1;
    end
    averageLength = totalTime / simulationTime;

    % Calculating the average (sojourn) time for a customer in the system
    arrivalTimesFixed = arrivalTimes(1:length(departureTimes)); % Match the arrivals with departures, to consider only customers who finish service
    customerLabelsFixed = customerLabels(1:length(departureTimes)); % Match customer labels too
    customerWait = departureTimes - arrivalTimesFixed; % Each individual customer's time in system
    averageCustomerTime = sum(customerWait) / length(arrivalTimesFixed);

    % Splitting up the uninformed and informed customer waiting times
    numUninformed = sum(1 - customerLabelsFixed); % number of uninformed customers who are served
    numInformed = sum(customerLabelsFixed); % number of informed customers who are served
    averageUninformedTime = sum(customerWait .* (1 - customerLabelsFixed)) / numUninformed;
    averageInformedTime = sum(customerWait .* customerLabelsFixed) / numInformed;

    % Calculating the proportion of time spent idle
    propIdle = idleTime / simulationTime;

    % Calculating the proportion of informed customers who join, rather than balk
    propJoinInformed = numInformed / (numInformed + balks);

    % Calculating the social welfare (sum of customer utilities)
    welfare = (R*length(departureTimes) - C*sum(customerWait))/simulationTime;

    % Plotting the sample path
    if plot == 1 && j == 1
        figure;
        stairs(timeEvents, stateEvents, 'LineWidth', 1.5);
        title_str = sprintf('Mixed Information Queue (lambda = %.1f, gamma = %.3f, N = %.0f, q = %.3f, )', lambda, gamma, n, q);
        title(title_str, "FontSize", 20);
        xlabel('Time (minutes)', "FontSize", 20);
        ylabel('Number of Customers in System', "FontSize", 20);
        grid on;
    end

    trialResults = [averageLength, averageCustomerTime, averageUninformedTime, averageInformedTime, propIdle, q, propJoinInformed, welfare];
    mixedResults(end+1, :) = trialResults;
end
mixedResults; % all results
[~, ~, ci] = ttest(mixedResults);
means = mean(mixedResults, 1);
ciLower = ci(1:2:end);
ciUpper = ci(2:2:end);
end