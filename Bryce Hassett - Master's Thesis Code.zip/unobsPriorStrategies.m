% This function generates the heatmaps for the social welfare and 
% throughput of the system over various off-equilibrium strategies 
% in Section 4.1.2 (Figures 4.7, 4.8, and 4.9).
% By Bryce Hassett

clc;
clear;
close all;
format short

rng(1);
trials = 100; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.5;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
simulationTime = 1000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 6; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
P = 4; % Priority fee
probs = 0:0.05:1; % Possible joining probabilities
priors = 0:0.05:1; % Possible priority purchasing probabilities

meanIdle = [];
meanWelfare = [];

count = 0;
for i = 1:length(probs)
    q = probs(i);
    for j = 1:length(priors)
        if i == 1 % prob of joining is zero
            meanIdle(i,j) = 1;
            meanWelfare(i,j) = 0;
            count = count+1;
            continue
        end
        
        p = priors(j);
        [unobsPriorAvg, unobsPriorCILow, unobsPriorCIHigh] = mm1unobsPrior(lambda, mu, R, C, P, q, p, simulationTime, trials, plots);

        meanIdle(i,j) = unobsPriorAvg(7);
        meanWelfare(i,j) = unobsPriorAvg(10);
        count = count + 1;


        disp(['Finished ', num2str(count), ' of ', num2str(length(probs)*length(priors))])
    end
end

% Average welfare
figure;
h1 = heatmap(priors, probs, meanWelfare);

sh = struct(h1);
sh.Axes.XLabel.FontSize = 16;
sh.Axes.YLabel.FontSize = 16;
sh.Axes.Title.FontSize = 16;

title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
h1.Title = title_str;
h1.XLabel = 'Probability of purchasing priority, p';
h1.YLabel = 'Probability of joining, q';
grid on;

% Average proportion of idle time
figure;
h2 = heatmap(priors, probs, meanIdle);

sh = struct(h2);
sh.Axes.XLabel.FontSize = 16;
sh.Axes.YLabel.FontSize = 16;
sh.Axes.Title.FontSize = 16;

title_str = sprintf('Average Proportion of Idle Time (lambda = %.1f, R = %.1f)', lambda, R);
h2.Title = title_str;
h2.XLabel = 'Probability of purchasing priority, p';
h2.YLabel = 'Probability of joining, q';
grid on;

% Average welfare between q = 0 and q = 0.6 % first 13 rows only (Figure 4.8)
probsShort = probs(1:13);
meanWelfareShort = meanWelfare(1:13, :);

figure;
h3 = heatmap(priors, probsShort, meanWelfareShort);

sh = struct(h3);
sh.Axes.XLabel.FontSize = 16;
sh.Axes.YLabel.FontSize = 16;
sh.Axes.Title.FontSize = 16;

title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
h3.Title = title_str;
h3.XLabel = 'Probability of purchasing priority, p';
h3.YLabel = 'Probability of joining, q';
grid on;