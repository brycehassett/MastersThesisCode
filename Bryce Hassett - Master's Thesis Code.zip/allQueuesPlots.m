% This function generates the plots describing the benefits of the 
% introduction of a priority fee to a mixed information FCFS queueing model, 
% and the introduction of information heterogeneity to priority queues, 
% in Section 6.2.
% By Bryce Hassett

clc;
clear;
close all;
rng(1);

unobsFCFSData = readtable('UnobsFCFS_parameter_sweep.csv');
obsFCFSData = readtable('ObsFCFS_parameter_sweep.csv');
mixedFCFSData = readtable('MixedFCFS_parameter_sweep.csv');
unobsPriorData = readtable('UnobsPrior_parameter_sweep.csv');
obsPriorData = readtable('ObsPrior_parameter_sweep.csv');
mipqData = readtable('MIPQ_parameter_sweep.csv'); % to not accidentally overwrite the csv


% List of possible parameter values in the data
% rhoVals = [0.2 0.5 0.9 1 1.1 1.5 2 2.5];
% muVals = 1;
gammaVals = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1];
% RVals = [5 10];
% CVals = 1;
% PVals = [0 2 5];

mu = 1;
C = 1;

% Plotting for various gamma
lambdaTargets = [0.5, 0.9, 1.1, 1.5, 2, 2.5];
RTarget = 5;
PTargets = [0, 2, 5];

lims = [0,1]; % bounds of the plots
%% Comparing MIPQ to mixed info FCFS (introduction of priority)

% Plotting for various P (tile for each lambda)

figure; % social welfare
t = tiledlayout(2, 3, 'TileSpacing', 'Compact');
for j = 1:length(lambdaTargets)
    nexttile;
    hold on;
    for i = 1:length(PTargets)
        mipqtargetRows = (mipqData.lambda == lambdaTargets(j)) & (mipqData.R == RTarget) & (mipqData.P == PTargets(i));
        mipqfilteredData = mipqData(mipqtargetRows, :);
        mipqwelNeg = mipqfilteredData.welfare - mipqfilteredData.welfareLower;
        mipqwelPos = mipqfilteredData.welfareUpper - mipqfilteredData.welfare;
        errorbar(mipqfilteredData.gamma, mipqfilteredData.welfare, mipqwelNeg, mipqwelPos, 'o-', 'LineWidth', 2);
        xlim(lims);
    end
    mixedFCFStargetRows = (mixedFCFSData.lambda == lambdaTargets(j)) & (mixedFCFSData.R == RTarget);
    mixedFCFSfilteredData = mixedFCFSData(mixedFCFStargetRows, :);
    mixedFCFSwelNeg = mixedFCFSfilteredData.welfare - mixedFCFSfilteredData.welfareLower;
    mixedFCFSwelPos = mixedFCFSfilteredData.welfareUpper - mixedFCFSfilteredData.welfare;
    errorbar(mixedFCFSfilteredData.gamma, mixedFCFSfilteredData.welfare, mixedFCFSwelNeg, mixedFCFSwelPos, 'o-', 'LineWidth', 2);
    title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(j));
    title(title_str, "FontSize", 20, 'interpreter', 'latex');
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Average social welfare', "FontSize", 20, 'Interpreter', 'latex');
lgd = legend("MIPQ (P = " + PTargets(1) + ")", "MIPQ (P = " + PTargets(2) + ")", "MIPQ (P = " + PTargets(3) + ")", "Mixed info FCFS", 'FontSize', 20, 'Location', 'northeastoutside');
lgd.Layout.Tile = 'east';
title_str = sprintf('Is priority beneficial for social welfare?');
title(t, title_str, "FontSize", 25);


figure; % throughput
t = tiledlayout(2, 3, 'TileSpacing', 'Compact');
for j = 1:length(lambdaTargets)
    nexttile;
    hold on;
    for i = 1:length(PTargets)
        mipqtargetRows = (mipqData.lambda == lambdaTargets(j)) & (mipqData.R == RTarget) & (mipqData.P == PTargets(i));
        mipqfilteredData = mipqData(mipqtargetRows, :);
        mipqidleNeg = mipqfilteredData.idleProb - mipqfilteredData.idleProbLower;
        mipqidlePos = mipqfilteredData.idleProbUpper - mipqfilteredData.idleProb;
        errorbar(mipqfilteredData.gamma, mipqfilteredData.idleProb, mipqidleNeg, mipqidlePos, 'o-', 'LineWidth', 2);
        xlim(lims);
    end
    mixedFCFStargetRows = (mixedFCFSData.lambda == lambdaTargets(j)) & (mixedFCFSData.R == RTarget);
    mixedFCFSfilteredData = mixedFCFSData(mixedFCFStargetRows, :);
    mixedFCFSidleNeg = mixedFCFSfilteredData.idleProb - mixedFCFSfilteredData.idleProbLower;
    mixedFCFSidlePos = mixedFCFSfilteredData.idleProbUpper - mixedFCFSfilteredData.idleProb;
    errorbar(mixedFCFSfilteredData.gamma, mixedFCFSfilteredData.idleProb, mixedFCFSidleNeg, mixedFCFSidlePos, 'o-', 'LineWidth', 2);
    title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(j));
    title(title_str, "FontSize", 20, 'interpreter', 'latex');
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Average proportion of idle time', "FontSize", 20, 'Interpreter', 'latex');
lgd = legend("MIPQ (P = " + PTargets(1) + ")", "MIPQ (P = " + PTargets(2) + ")", "MIPQ (P = " + PTargets(3) + ")", "Mixed info FCFS", 'FontSize', 20, 'Location', 'northeastoutside');
lgd.Layout.Tile = 'east';
title_str = sprintf('Is priority beneficial for throughput?');
title(t, title_str, "FontSize", 25);

%% Comparing MIPQ to observable and unobservable priority queues
% Plotting for various P (tile for each lambda)
colours = ["blue", "#EDB120", "red"];
figure; % social welfare
t = tiledlayout(2, 3, 'TileSpacing', 'Compact');
for j = 1:length(lambdaTargets)
    nexttile;
    hold on;
    for i = 1:length(PTargets)
        mipqtargetRows = (mipqData.lambda == lambdaTargets(j)) & (mipqData.R == RTarget) & (mipqData.P == PTargets(i));
        mipqfilteredData = mipqData(mipqtargetRows, :);
        mipqwelNeg = mipqfilteredData.welfare - mipqfilteredData.welfareLower;
        mipqwelPos = mipqfilteredData.welfareUpper - mipqfilteredData.welfare;
        errorbar(mipqfilteredData.gamma, mipqfilteredData.welfare, mipqwelNeg, mipqwelPos, 'o-', 'LineWidth', 2, 'Color', colours(i));
        
        unobsPriortargetRows = (unobsPriorData.lambda == lambdaTargets(j)) & (unobsPriorData.R == RTarget) & (unobsPriorData.P == PTargets(i));
        unobsPriorfilteredData = unobsPriorData(unobsPriortargetRows, :);
        plot(gammaVals, unobsPriorfilteredData.welfare*ones(1,length(gammaVals)), 'd', 'LineWidth', 2, 'LineStyle', ':', 'Color', colours(i));

        obsPriortargetRows = (obsPriorData.lambda == lambdaTargets(j)) & (obsPriorData.R == RTarget) & (obsPriorData.P == PTargets(i));
        obsPriorfilteredData = obsPriorData(obsPriortargetRows, :);
        plot(gammaVals, obsPriorfilteredData.welfare*ones(1,length(gammaVals)), 's', 'LineWidth', 2, 'LineStyle', ':', 'Color', colours(i));

        xlim(lims);
    end
    title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(j));
    title(title_str, "FontSize", 20, 'interpreter', 'latex');
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Average social welfare', "FontSize", 20, 'Interpreter', 'latex');
lgd = legend("MIPQ (P = " + PTargets(1) + ")", "Unobservable (P = " + PTargets(1) + ")", "Observable (P = " + PTargets(1) + ")", "MIPQ (P = " + PTargets(2) + ")", "Unobservable (P = " + PTargets(2) + ")", "Observable (P = " + PTargets(2) + ")", "MIPQ (P = " + PTargets(3) + ")", "Unobservable (P = " + PTargets(3) + ")", "Observable (P = " + PTargets(3) + ")", 'FontSize', 20, 'Location', 'northeastoutside');
lgd.Layout.Tile = 'east';
title_str = sprintf('Is information heterogeneity beneficial for social welfare?');
title(t, title_str, "FontSize", 25);

figure; % social welfare
t = tiledlayout(2, 3, 'TileSpacing', 'Compact');
for j = 1:length(lambdaTargets)
    nexttile;
    hold on;
    for i = 1:length(PTargets)
        mipqtargetRows = (mipqData.lambda == lambdaTargets(j)) & (mipqData.R == RTarget) & (mipqData.P == PTargets(i));
        mipqfilteredData = mipqData(mipqtargetRows, :);
        mipqidleNeg = mipqfilteredData.idleProb - mipqfilteredData.idleProbLower;
        mipqidlePos = mipqfilteredData.idleProbUpper - mipqfilteredData.idleProb;
        errorbar(mipqfilteredData.gamma, mipqfilteredData.idleProb, mipqidleNeg, mipqidlePos, 'o-', 'LineWidth', 2, 'Color', colours(i));
        
        unobsPriortargetRows = (unobsPriorData.lambda == lambdaTargets(j)) & (unobsPriorData.R == RTarget) & (unobsPriorData.P == PTargets(i));
        unobsPriorfilteredData = unobsPriorData(unobsPriortargetRows, :);
        plot(gammaVals, unobsPriorfilteredData.idleProb*ones(1,length(gammaVals)), 'd', 'LineWidth', 2, 'LineStyle', ':', 'Color', colours(i));

        obsPriortargetRows = (obsPriorData.lambda == lambdaTargets(j)) & (obsPriorData.R == RTarget) & (obsPriorData.P == PTargets(i));
        obsPriorfilteredData = obsPriorData(obsPriortargetRows, :);
        plot(gammaVals, obsPriorfilteredData.idleProb*ones(1,length(gammaVals)), 's', 'LineWidth', 2, 'LineStyle', ':', 'Color', colours(i));

        xlim(lims);
    end
    title_str = sprintf('$\\mathbf{\\lambda}$ $\\mathbf{=}$ $\\mathbf{%.1f}$', lambdaTargets(j));
    title(title_str, "FontSize", 20, 'interpreter', 'latex');
    ax = gca;
    ax.XAxis.FontSize = 13;
    ay = gca;
    ay.YAxis.FontSize = 13;
    grid on;
    hold off;
end
xlabel(t, 'Proportion of informed customers, $\gamma$', "FontSize", 20, 'Interpreter', 'latex');
ylabel(t, 'Average proportion of idle time', "FontSize", 20, 'Interpreter', 'latex');
lgd = legend("MIPQ (P = " + PTargets(1) + ")", "Unobservable (P = " + PTargets(1) + ")", "Observable (P = " + PTargets(1) + ")", "MIPQ (P = " + PTargets(2) + ")", "Unobservable (P = " + PTargets(2) + ")", "Observable (P = " + PTargets(2) + ")", "MIPQ (P = " + PTargets(3) + ")", "Unobservable (P = " + PTargets(3) + ")", "Observable (P = " + PTargets(3) + ")", 'FontSize', 20, 'Location', 'northeastoutside');
lgd.Layout.Tile = 'east';
title_str = sprintf('Is information heterogeneity beneficial for throughput?');
title(t, title_str, "FontSize", 25);