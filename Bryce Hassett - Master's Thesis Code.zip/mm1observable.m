% This function simulates the fully observable FCFS queue, from 
% Section 3.2, for a specified parameter set, and outputs a sample path 
% and the resulting performance measures (for example, Figures 3.6 and 3.7).
% By Bryce Hassett

function [means, ciLower, ciUpper] = mm1observable(lambda, mu, R, C, N, simulationTime, trials, plot)

obsResults = [];

for j = 1:trials
    % Initialization
    currentTime = 0;
    customersInSystem = 0;
    timeEvents = 0; % Times when either an arrival or departure occurs
    stateEvents = 0; % Number of customers in system when an event occurs
    idleTime = 0; % Keep track of idle time
    arrivals = 0; % Number of customers who actually join the queue
    arrivalTimes = [];
    departureTimes = [];
    balks = 0; % Number of customers who choose to not join the queue
    % Note that now the "arrivals" parameter corresponds to those who actually choose to join the queue

    % Simulation Loop
    while currentTime < simulationTime
        % Generate next arrival and service times (Exponential Distribution)
        arrivalInterval = exprnd(1/lambda); % Argument is mean, so reciprocal
        serviceDuration = exprnd(1/mu);
        if customersInSystem == 0
            nextEvent = arrivalInterval;
        else
            if arrivalInterval < serviceDuration
                nextEvent = arrivalInterval;
            else
                nextEvent = serviceDuration;
            end
        end
        if currentTime + nextEvent > simulationTime % Exit the loop if the next arrival/service event exceeds simulation time
            break;
        end

        % If system is empty, next event must be an arrival
        if customersInSystem == 0 % Assume that a rational customer will always join an empty queue (optionally, modify this to include cases when this is false)
            idleTime = idleTime + arrivalInterval;
            currentTime = currentTime + arrivalInterval;
            customersInSystem = 1;
            arrivals = arrivals + 1;
            arrivalTimes = [arrivalTimes, currentTime];
        else
            % Compare next arrival and next service completion (this works
            % because of the memoryless property of exponentials)
            if arrivalInterval < serviceDuration
                % Arrival happens first
                currentTime = currentTime + arrivalInterval;
                if customersInSystem < N % The queue is short enough for the customer to join
                    customersInSystem = customersInSystem + 1;
                    arrivals = arrivals + 1;
                    arrivalTimes = [arrivalTimes, currentTime];
                else
                    balks = balks + 1; % Otherwise, they balk
                end

            else
                % Service completion happens first
                currentTime = currentTime + serviceDuration;
                customersInSystem = customersInSystem - 1;
                departureTimes = [departureTimes, currentTime];
            end
        end

        % Record events for plotting
        timeEvents = [timeEvents, currentTime];
        stateEvents = [stateEvents, customersInSystem];
    end

    % for debugging
    timeEvents;
    stateEvents;
    arrivalTimes;
    departureTimes;

    % Calculating the average queue length (area under plot)
    totalTime = 0;
    i = 1;
    while i < length(stateEvents)
        totalTime = totalTime + (stateEvents(i) * (timeEvents(i+1)-timeEvents(i)));
        i = i+1;
    end
    averageLength = totalTime / simulationTime;

    % Calculating the average (sojourn) time for a customer in the system
    arrivalTimesFixed = arrivalTimes(1:length(departureTimes)); % Match the arrivals with departures, to consider only customers who finish service
    customerWait = departureTimes - arrivalTimesFixed; % Each individual customer's time in system
    averageCustomerTime = sum(customerWait) / length(arrivalTimesFixed);

    % Calculating the proportion of time spent idle
    propIdle = idleTime / simulationTime;

    % Calculating the proportion of customers who actually join the system,
    % instead of balking
    propJoin = arrivals / (arrivals + balks);

    % Calculating the social welfare (sum of customer utilities)
    avgWelfare = (R*length(departureTimes) - C*sum(customerWait))/simulationTime;
    
    % Plotting the sample path
    if plot == 1 && j == 1
        figure;
        stairs(timeEvents, stateEvents, 'LineWidth', 1.5);
        title_str = sprintf('Observable Queue Simulation (lambda = %.1f, mu = %.1f, R = %.1f, C = %.1f)', lambda, mu, R, C);
        title(title_str, "FontSize", 20);
        xlabel('Time (minutes)', "FontSize", 20);
        ylabel('Number of Customers in System', "FontSize", 20);
        grid on;
    end

    trialResults = [averageLength, averageCustomerTime, propIdle, propJoin, avgWelfare];
    obsResults(end+1, :) = trialResults;
end
obsResults; % all results
[~, ~, ci] = ttest(obsResults);
means = mean(obsResults, 1);
ciLower = ci(1:2:end);
ciUpper = ci(2:2:end);
end