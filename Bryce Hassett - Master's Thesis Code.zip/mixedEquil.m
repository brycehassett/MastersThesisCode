% This function computes the equilibrium strategy (n, q) for the 
% mixed information FCFS queue, from Section 3.3.1
% By Bryce Hassett

function [n, q] = mixedEquil(lambda, mu, R, C, gamma)

rho = lambda/mu;
v = R*mu/C;
n = floor(v);

% If all customers are informed, q is irrelevant.
if gamma == 1
    q = 1;
    return
end

infArrival = gamma*lambda;
uninfArrival = (1-gamma)*lambda;

% Compute joining probability for uninformed customers, q
rhoLow = 1-1/v;

syms y real % Declare symbolic variables
eqn = n+1+1/(1-y)-(n+1)/(1-y^(n+1)) == v; % Set the equation
sols = vpasolve(eqn, y); % Solve for y
rhoHigh = sols(imag(sols)==0 & sols > 0);

% Information thresholds
gamma0 = rhoHigh/rho;
vbracket = v-n;
L = (vbracket*(rho-1)*rho^n+v-v*rho+rho^n-1)/((1-rho)^2*rho^n);
gamma1 = 1 - 1/rho + (2/rho)*(vbracket+sqrt(vbracket^2+4*L))^(-1);

if rho < rhoLow % (i)
    qe = 1;
elseif rho > rhoHigh % (iii)
    if gamma >= gamma0
        qe = 0;
    else
        syms q real
        rhoC = (infArrival+q*uninfArrival)/mu;
        rhoU = q*uninfArrival/mu;
        idle = ((1-(rhoC)^n)/(1-rhoC)+((rhoC)^n)/(1-rhoU))^(-1);
        waitEqn = (idle/mu)*((1-(rhoC)^n)/(1-rhoC)+rhoC/((1-rhoC)^2)+(rhoC)^n*((1-n)/(1-rhoC)-1/((1-rhoC)^2)+1/((1-rhoU)^2)+n/(1-rhoU))) == R/C;
        sol = vpasolve(waitEqn, q);
        qe = sol(imag(sol)==0 & sol > 0);
    end
else % (ii)
    if gamma >= gamma1
        qe = 1;
    else
        syms q real
        rhoC = (infArrival+q*uninfArrival)/mu;
        rhoU = q*uninfArrival/mu;
        idle = ((1-(rhoC)^n)/(1-rhoC)+((rhoC)^n)/(1-rhoU))^(-1);
        waitEqn = (idle/mu)*((1-(rhoC)^n)/(1-rhoC)+rhoC/((1-rhoC)^2)+(rhoC)^n*((1-n)/(1-rhoC)-1/((1-rhoC)^2)+1/((1-rhoU)^2)+n/(1-rhoU))) == v;
        sol = vpasolve(waitEqn, q);
        qe = sol(imag(sol)==0 & sol > 0);
    end
end
q = double(qe);