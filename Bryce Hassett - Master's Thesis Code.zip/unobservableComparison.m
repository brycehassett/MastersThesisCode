% This function provides a comparison between the unobservable FCFS and 
% priority queues, over various priority fees (Figure 4.6). It also 
% outputs a plot for the probability of purchasing priority over various 
% priority fees (Figure 4.5).
% By Bryce Hassett

clc;
clear;
close all;
format short

rng(1);
trials = 100; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.5;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
simulationTime = 10000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 6; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
premiums = 0:0.5:R; % Priority fees

meanWait = [];
lowerWait = [];
upperWait = [];
meanIdle = [];
lowerIdle = [];
upperIdle = [];
meanJoin = [];
lowerJoin = [];
upperJoin = [];
meanPrior = [];
lowerPrior = [];
upperPrior = [];
meanWelfare = [];
lowerWelfare = [];
upperWelfare = [];

% M/M/1 Unobservable Queue (with balking)
q = unobsEquil(lambda, mu, R, C);
[unobsAvg, unobsCILow, unobsCIHigh] = mm1unobservable(lambda, mu, R, C, q, simulationTime, trials, plots);

FCFSmeanWait = unobsAvg(2)*ones(1, length(premiums));
FCFSlowerWait = unobsCILow(2)*ones(1, length(premiums));
FCFSupperWait = unobsCIHigh(2)*ones(1, length(premiums));

FCFSmeanIdle = unobsAvg(3)*ones(1, length(premiums));
FCFSlowerIdle = unobsCILow(3)*ones(1, length(premiums));
FCFSupperIdle = unobsCIHigh(3)*ones(1, length(premiums));

FCFSmeanWelfare = unobsAvg(5)*ones(1, length(premiums));
FCFSlowerWelfare = unobsCILow(5)*ones(1, length(premiums));
FCFSupperWelfare = unobsCIHigh(5)*ones(1, length(premiums));

FCFSmeanJoin = q*ones(1, length(premiums));

% M/M/1 Unobservable Priority Queue (with balking)
disp("Unobservable Priority Queue")
for i = 1:length(premiums)
    P = premiums(i);
    [q,p] = unobsPriorEquil(lambda, mu, R, C, P);
    [unobsPriorAvg, unobsPriorCILow, unobsPriorCIHigh] = mm1unobsPrior(lambda, mu, R, C, P, q, p, simulationTime, trials, plots);
    
    meanWait = [meanWait, unobsPriorAvg(4)];
    lowerWait = [lowerWait, unobsPriorCILow(4)];
    upperWait = [upperWait, unobsPriorCIHigh(4)];

    meanIdle = [meanIdle, unobsPriorAvg(7)];
    lowerIdle = [lowerIdle, unobsPriorCILow(7)];
    upperIdle = [upperIdle, unobsPriorCIHigh(7)];

    meanJoin = [meanJoin, unobsPriorAvg(8)];
    lowerJoin = [lowerJoin, unobsPriorCILow(8)];
    upperJoin = [upperJoin, unobsPriorCIHigh(8)];

    meanPrior = [meanPrior, unobsPriorAvg(9)];
    lowerPrior = [lowerPrior, unobsPriorCILow(9)];
    upperPrior = [upperPrior, unobsPriorCIHigh(9)];

    meanWelfare = [meanWelfare, unobsPriorAvg(10)];
    lowerWelfare = [lowerWelfare, unobsPriorCILow(10)];
    upperWelfare = [upperWelfare, unobsPriorCIHigh(10)];

    disp(['Finished PQ ', num2str(i), ' of ', num2str(length(premiums))])
end

%premiums
%meanWait
%meanIdle
%meanJoin
%meanPrior
%meanWelfare

% Average customer waiting time
waitNeg = meanWait - lowerWait;
waitPos = upperWait - meanWait;
figure;
hold on;
errorbar(premiums, meanWait, waitNeg, waitPos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanWait, '-o', 'LineWidth', 2)
title_str = sprintf('Average Waiting Time (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Average waiting time (minutes)', "FontSize", 20);
legend('Priority Queue', 'FCFS Queue');
grid on;

% Average idle time
idleNeg = meanIdle - lowerIdle;
idlePos = upperIdle - meanIdle;
figure;
hold on;
errorbar(premiums, meanIdle, idleNeg, idlePos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanIdle, '-o', 'LineWidth', 2)
title_str = sprintf('Average Proportion of Idle Time (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Average idle time', "FontSize", 20);
legend('Priority Queue', 'FCFS Queue');
grid on;

% Average welfare
welfareNeg = meanWelfare - lowerWelfare;
welfarePos = upperWelfare - meanWelfare;
figure;
hold on;
errorbar(premiums, meanWelfare, welfareNeg, welfarePos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanWelfare, '-o', 'LineWidth', 2)
title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Social Welfare', "FontSize", 20);
legend('Priority Queue', 'FCFS Queue');
grid on;

% Joining probability
figure;
hold on;
plot(premiums, meanJoin, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanJoin, '-o', 'LineWidth', 2)
title_str = sprintf('Probability of joining (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Probability', "FontSize", 20);
legend('Priority Queue', 'FCFS Queue');
grid on;

% Priority probability
figure;
plot(premiums, meanPrior, '-o', 'LineWidth', 2)
title_str = sprintf('Probability of purchasing priority (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 20);
ylabel('Probability', "FontSize", 20);
grid on;

t = tiledlayout(2, 2);

nexttile;
hold on;
errorbar(premiums, meanWait, waitNeg, waitPos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanWait, '-o', 'LineWidth', 2)
title_str = sprintf('(a) Average Waiting Time');
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 15);
legend('Priority Queue', 'FCFS Queue');

nexttile;
hold on;
errorbar(premiums, meanIdle, idleNeg, idlePos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanIdle, '-o', 'LineWidth', 2)
title_str = sprintf('(b) Average Proportion of Idle Time');
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 15);
legend('Priority Queue', 'FCFS Queue');

nexttile;
hold on;
errorbar(premiums, meanWelfare, welfareNeg, welfarePos, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanWelfare, '-o', 'LineWidth', 2)
title_str = sprintf('(c) Social Welfare');
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 15);
legend('Priority Queue', 'FCFS Queue');

nexttile;
hold on;
plot(premiums, meanJoin, '-o', 'LineWidth', 2)
plot(premiums, FCFSmeanJoin, '-o', 'LineWidth', 2)
title_str = sprintf('(d) Probability of joining');
title(title_str, "FontSize", 20);
xlabel('Priority fee cost', "FontSize", 15);
legend('Priority Queue', 'FCFS Queue');