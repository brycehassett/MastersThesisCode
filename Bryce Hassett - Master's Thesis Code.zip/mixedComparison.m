% This function provides a comparison between the three types of 
% FCFS queues (unobservable, observable, and mixed), and plots four 
% performance metrics over the information level, when customers use the 
% equilibrium strategy (Figure 3.11).
% By Bryce Hassett

clc;
clear;
close all;
format short

rng(1);
trials = 100; % runs of each queueing model
plots = 0;

% M/M/1 Queue Simulation
lambda = 1.5;  % Arrival rate (customers/minute)
mu = 1;      % Service rate (customers/minute)
simulationTime = 10000; % Total simulation time (minutes)

% Strategic Queueing Parameters
R = 6; % Reward for service completion
C = 1; % Cost per unit of time spent in the system
gammas = 0:0.05:1; % Information levels

meanWait = [];
lowerWait = [];
upperWait = [];
meanIdle = [];
lowerIdle = [];
upperIdle = [];
meanJoin = [];
lowerJoin = [];
upperJoin = [];
meanWelfare = [];
lowerWelfare = [];
upperWelfare = [];

% M/M/1 Observable Queue (with balking)
disp("Observable Queue")
n = floor(R*mu/C);
[obsAvg, obsCILow, obsCIHigh] = mm1observable(lambda, mu, R, C, n, simulationTime, trials, plots);

OBSmeanWait = obsAvg(2)*ones(1, length(gammas));
OBSlowerWait = obsCILow(2)*ones(1, length(gammas));
OBSupperWait = obsCIHigh(2)*ones(1, length(gammas));

OBSmeanIdle = obsAvg(3)*ones(1, length(gammas));
OBSlowerIdle = obsCILow(3)*ones(1, length(gammas));
OBSupperIdle = obsCIHigh(3)*ones(1, length(gammas));

OBSmeanJoin = obsAvg(4)*ones(1, length(gammas));
OBSlowerJoin = obsCILow(4)*ones(1, length(gammas));
OBSupperJoin = obsCIHigh(4)*ones(1, length(gammas));

OBSmeanWelfare = obsAvg(5)*ones(1, length(gammas));
OBSlowerWelfare = obsCILow(5)*ones(1, length(gammas));
OBSupperWelfare = obsCIHigh(5)*ones(1, length(gammas));

% M/M/1 Unobservable Queue (with balking)
disp("Unobservable Queue")
q = unobsEquil(lambda, mu, R, C);
[unobsAvg, unobsCILow, unobsCIHigh] = mm1unobservable(lambda, mu, R, C, q, simulationTime, trials, plots);

UNOBSmeanWait = unobsAvg(2)*ones(1, length(gammas));
UNOBSlowerWait = unobsCILow(2)*ones(1, length(gammas));
UNOBSupperWait = unobsCIHigh(2)*ones(1, length(gammas));

UNOBSmeanIdle = unobsAvg(3)*ones(1, length(gammas));
UNOBSlowerIdle = unobsCILow(3)*ones(1, length(gammas));
UNOBSupperIdle = unobsCIHigh(3)*ones(1, length(gammas));

UNOBSmeanWelfare = unobsAvg(5)*ones(1, length(gammas));
UNOBSlowerWelfare = unobsCILow(5)*ones(1, length(gammas));
UNOBSupperWelfare = unobsCIHigh(5)*ones(1, length(gammas));

UNOBSmeanJoin = q*ones(1, length(gammas));

% M/M/1 Mixed Information Queue (with balking)
disp("Mixed Information Queue")
for i = 1:length(gammas)
    gamma = gammas(i);
    [n, q] = mixedEquil(lambda, mu, R, C, gamma);
    [mixedAvg, mixedCILow, mixedCIHigh] = mixedQueue(lambda, mu, R, C, gamma, q, n, simulationTime, trials, plots);
    
    meanWait = [meanWait, mixedAvg(2)];
    lowerWait = [lowerWait, mixedCILow(2)];
    upperWait = [upperWait, mixedCIHigh(2)];

    meanIdle = [meanIdle, mixedAvg(5)];
    lowerIdle = [lowerIdle, mixedCILow(5)];
    upperIdle = [upperIdle, mixedCIHigh(5)];

    meanJoin = [meanJoin, gamma*mixedAvg(7) + (1-gamma)*mixedAvg(6)];
    lowerJoin = [lowerJoin, gamma*mixedCILow(7) + (1-gamma)*mixedCILow(6)];
    upperJoin = [upperJoin, gamma*mixedCIHigh(7) + (1-gamma)*mixedCIHigh(6)];

    meanWelfare = [meanWelfare, mixedAvg(8)];
    lowerWelfare = [lowerWelfare, mixedCILow(8)];
    upperWelfare = [upperWelfare, mixedCIHigh(8)];

    disp(['Finished PQ ', num2str(i), ' of ', num2str(length(gammas))])
end

% Average customer waiting time
waitNeg = meanWait - lowerWait;
waitPos = upperWait - meanWait;
OBSwaitNeg = OBSmeanWait - OBSlowerWait;
OBSwaitPos = OBSupperWait - OBSmeanWait;
UNOBSwaitNeg = UNOBSmeanWait - UNOBSlowerWait;
UNOBSwaitPos = UNOBSupperWait - UNOBSmeanWait;

figure;
hold on;
errorbar(gammas, meanWait, waitNeg, waitPos, '-o', 'LineWidth', 2)
errorbar(gammas, UNOBSmeanWait, UNOBSwaitNeg, UNOBSwaitPos, '-o', 'LineWidth', 2)
errorbar(gammas, OBSmeanWait, OBSwaitNeg, OBSwaitPos, '-o', 'LineWidth', 2)
title_str = sprintf('Average Waiting Time (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Information Level', "FontSize", 20);
ylabel('Average waiting time (minutes)', "FontSize", 20);
legend('Mixed', 'Unobservable', 'Observable');
grid on;

% Average idle time
idleNeg = meanIdle - lowerIdle;
idlePos = upperIdle - meanIdle;
OBSidleNeg = OBSmeanIdle - OBSlowerIdle;
OBSidlePos = OBSupperIdle - OBSmeanIdle;
UNOBSidleNeg = UNOBSmeanIdle - UNOBSlowerIdle;
UNOBSidlePos = UNOBSupperIdle - UNOBSmeanIdle;

figure;
hold on;
errorbar(gammas, meanIdle, idleNeg, idlePos, '-o', 'LineWidth', 2)
errorbar(gammas, UNOBSmeanIdle, UNOBSidleNeg, UNOBSidlePos, '-o', 'LineWidth', 2)
errorbar(gammas, OBSmeanIdle, OBSidleNeg, OBSidlePos, '-o', 'LineWidth', 2)
title_str = sprintf('Average Proportion of Idle Time (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Information Level', "FontSize", 20);
ylabel('Average idle time', "FontSize", 20);
legend('Mixed', 'Unobservable', 'Observable');
grid on;

% Average welfare
welfareNeg = meanWelfare - lowerWelfare;
welfarePos = upperWelfare - meanWelfare;
OBSwelfareNeg = OBSlowerWelfare - OBSlowerWelfare;
OBSwelfarePos = OBSupperWelfare - OBSmeanWelfare;
UNOBSwelfareNeg = UNOBSmeanWelfare - UNOBSlowerWelfare;
UNOBSwelfarePos = UNOBSupperWelfare - UNOBSmeanWelfare;

figure;
hold on;
errorbar(gammas, meanWelfare, welfareNeg, welfarePos, '-o', 'LineWidth', 2)
errorbar(gammas, UNOBSmeanWelfare, UNOBSwelfareNeg, UNOBSwelfarePos, '-o', 'LineWidth', 2)
errorbar(gammas, OBSmeanWelfare, OBSwelfareNeg, OBSwelfarePos, '-o', 'LineWidth', 2)
title_str = sprintf('Social Welfare (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Information Level', "FontSize", 20);
ylabel('Social Welfare', "FontSize", 20);
legend('Mixed', 'Unobservable', 'Observable');
grid on;

% Joining probability
joinNeg = meanJoin - lowerJoin;
joinPos = upperJoin - meanJoin;
OBSjoinNeg = OBSlowerJoin - OBSlowerJoin;
OBSjoinPos = OBSupperJoin - OBSmeanJoin;

figure;
hold on;
errorbar(gammas, meanJoin, joinNeg, joinPos, '-o', 'LineWidth', 2)
plot(gammas, UNOBSmeanJoin, '-o', 'LineWidth', 2)
errorbar(gammas, OBSmeanJoin, OBSjoinNeg, OBSjoinPos, '-o', 'LineWidth', 2)
title_str = sprintf('Probability of joining (lambda = %.1f, R = %.1f)', lambda, R);
title(title_str, "FontSize", 20);
xlabel('Information Level', "FontSize", 20);
ylabel('Probability', "FontSize", 20);
legend('Mixed', 'Unobservable', 'Observable');
grid on;

figure;
t = tiledlayout(2, 2);

nexttile;
hold on;
errorbar(gammas, meanWait, waitNeg, waitPos, '-o', 'LineWidth', 2)
errorbar(gammas, UNOBSmeanWait, UNOBSwaitNeg, UNOBSwaitPos, '-o', 'LineWidth', 2)
errorbar(gammas, OBSmeanWait, OBSwaitNeg, OBSwaitPos, '-o', 'LineWidth', 2)
title_str = sprintf('(a) Average Waiting Time');
title(title_str, "FontSize", 20);
xlabel('Information Level', "FontSize", 16);
legend('Mixed', 'Unobservable', 'Observable');

nexttile;
hold on;
errorbar(gammas, meanIdle, idleNeg, idlePos, '-o', 'LineWidth', 2)
errorbar(gammas, UNOBSmeanIdle, UNOBSidleNeg, UNOBSidlePos, '-o', 'LineWidth', 2)
errorbar(gammas, OBSmeanIdle, OBSidleNeg, OBSidlePos, '-o', 'LineWidth', 2)
title_str = sprintf('(b) Average Proportion of Idle Time');
title(title_str, "FontSize", 20);
xlabel('Information Level', "FontSize", 16);
legend('Mixed', 'Unobservable', 'Observable');

nexttile;
hold on;
errorbar(gammas, meanWelfare, welfareNeg, welfarePos, '-o', 'LineWidth', 2)
errorbar(gammas, UNOBSmeanWelfare, UNOBSwelfareNeg, UNOBSwelfarePos, '-o', 'LineWidth', 2)
errorbar(gammas, OBSmeanWelfare, OBSwelfareNeg, OBSwelfarePos, '-o', 'LineWidth', 2)
title_str = sprintf('(c) Social Welfare');
title(title_str, "FontSize", 20);
xlabel('Information Level', "FontSize", 16);
legend('Mixed', 'Unobservable', 'Observable');

nexttile;
hold on;
errorbar(gammas, meanJoin, joinNeg, joinPos, '-o', 'LineWidth', 2)
plot(gammas, UNOBSmeanJoin, '-o', 'LineWidth', 2)
errorbar(gammas, OBSmeanJoin, OBSjoinNeg, OBSjoinPos, '-o', 'LineWidth', 2)
title_str = sprintf('(d) Probability of joining');
title(title_str, "FontSize", 20);
xlabel('Information Level', "FontSize", 16);
legend('Mixed', 'Unobservable', 'Observable');